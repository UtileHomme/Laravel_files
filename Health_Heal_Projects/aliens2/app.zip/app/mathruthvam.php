<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mathruthvam extends Model
{
    //
}
