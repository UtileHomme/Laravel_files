<?php $__env->startSection('editid', $leadtype->id); ?>
<?php $__env->startSection('editleadtypes',$leadtype->leadtypes); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo e(method_field('PUT')); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('leadtype.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>