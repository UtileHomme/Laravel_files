<?php $__env->startSection('body'); ?>
<div>


<br>
<a href="/admin/customercare" class="btn btn-info" >Home</a>

<div class="">
<h1><?php echo e(substr(Route::currentRouteName(),9)); ?> Lead Registration</h1>
<form class="form-horizontal" action="/cc/<?php echo $__env->yieldContent('editid'); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo $__env->yieldSection(); ?>
  <fieldset>
     <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Client Details</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">

       <label>Client First Name<input type="text" class="form-control" rows="5" name="clientfname" id="clientfname" value="<?php echo $__env->yieldContent('editclientfname'); ?>"></label>
        &emsp;
         <label>Middle Name<input type="text" class="form-control" rows="5" name="clientmname" id="clientmname" value="<?php echo $__env->yieldContent('editclientmname'); ?>"></label>
        &emsp;
         <label>Last Name<input type="text" class="form-control" rows="5" name="clientlname" id="clientlname" value="<?php echo $__env->yieldContent('editclientlname'); ?>"></label>
        &emsp;
        <label>Client Email ID <input type="text" class="form-control" rows="5" name="clientemail" id="clientemail" value="<?php echo $__env->yieldContent('editclientemail'); ?>"></label>
        &emsp;
        <label>Source <input type="text" class="form-control" rows="5" name="source" id="source" value="<?php echo $__env->yieldContent('editsource'); ?>"></label>
        &emsp;
        <label>Client Mob. no. 
        &emsp;



        <select id="country">
        <option value="">Select Code</option>
          <option value="+91">India</option>
          <option value="+1">US</option>
          <option value="+44 ">UK</option>
          </select>
        <input type="text" id="phone" class="form-control" rows="5" name="clientmob" id="clientmob" value="<?php echo $__env->yieldContent('editclientmob'); ?>">

        </label>
        &emsp;
        <label>Client Alternate no. <input type="text" class="form-control" rows="5" name="clientalternateno" id="clientalternateno" value="<?php echo $__env->yieldContent('editclientalternateno'); ?>"></label>
        &emsp;
        <label>Emergency Contact no. <input type="text" class="form-control" rows="5" name="EmergencyContact" id="EmergencyContact" value="<?php echo $__env->yieldContent('editEmergencyContact'); ?>"></label>
        &emsp;
        <label>Assessment Required 
          <select name="assesmentreq" id="assesmentreq" class="form-control">
            <option value="yes">YES</option>
            <option value="no">NO</option>
          </select>
        </label>
        &emsp;
        <label>Reference ID 
        <select name="reference" id="reference" class="form-control">
            <?php $__currentLoopData = $reference; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($reference->Reference); ?>"><?php echo e($reference->Reference); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
           </label>
        &emsp;
        <br>
<h2>Permanent Address</h2>

<label>Address Line 1<input type="text" class="form-control" rows="5" name="Address1" id="Address1" value="<?php echo $__env->yieldContent('editAddress1'); ?>"></label>
        &emsp;
<label>Address Line 2<input type="text" class="form-control" rows="5" name="Address2" id="Address2" value="<?php echo $__env->yieldContent('editAddress2'); ?>"></label>
        &emsp;
        <label>City<input type="text" class="form-control" rows="5" name="City" id="City" value="<?php echo $__env->yieldContent('editCity'); ?>"></label>
        &emsp;
         <label>District<input type="text" class="form-control" rows="5" name="District" id="District" value="<?php echo $__env->yieldContent('editDistrict'); ?>"></label>
        &emsp;
        <label>State<input type="text" class="form-control" rows="5" name="State" id="State" value="<?php echo $__env->yieldContent('editState'); ?>"></label>
        &emsp;
        <label>PinCode<input type="text" class="form-control" rows="5" name="PinCode" id="PinCode" value="<?php echo $__env->yieldContent('editPinCode'); ?>"></label>
        &emsp;
<br>
<br>
<input type="checkbox" name="presentcontact" value="same"> Same as Permanent Address<br>
<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse11">Present Address</a>
        </h4>
      </div>
      <div id="collapse11" class="panel-collapse collapse">
        <div class="panel-body">

<label>Address Line 1<input type="text" class="form-control" rows="5" name="PAddress1" id="PAddress1" value="<?php echo $__env->yieldContent('editPAddress1'); ?>"></label>
        &emsp;
<label>Address Line 2<input type="text" class="form-control" rows="5" name="PAddress2" id="PAddress2" value="<?php echo $__env->yieldContent('editPAddress2'); ?>"></label>
        &emsp;
        <label>City<input type="text" class="form-control" rows="5" name="PCity" id="PCity" value="<?php echo $__env->yieldContent('editPCity'); ?>"></label>
        &emsp;
         <label>District<input type="text" class="form-control" rows="5" name="PDistrict" id="PDistrict" value="<?php echo $__env->yieldContent('editPDistrict'); ?>"></label>
        &emsp;
        <label>State<input type="text" class="form-control" rows="5" name="PState" id="PState" value="<?php echo $__env->yieldContent('editPState'); ?>"></label>
        &emsp;
        <label>PinCode<input type="text" class="form-control" rows="5" name="PPinCode" id="PPinCode" value="<?php echo $__env->yieldContent('editPPinCode'); ?>"></label>
     

        </div>
        </div>
        </div>

<input type="checkbox" name="emergencycontact" value="same"> Same as Permanent Address<br>
        <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse21">Emergency Address</a>
        </h4>
      </div>
      <div id="collapse21" class="panel-collapse collapse">
        <div class="panel-body">

<label>Address Line 1<input type="text" class="form-control" rows="5" name="EAddress1" id="EAddress1" value="<?php echo $__env->yieldContent('editEAddress1'); ?>"></label>
        &emsp;
<label>Address Line 2<input type="text" class="form-control" rows="5" name="EAddress2" id="EAddress2" value="<?php echo $__env->yieldContent('editEAddress2'); ?>"></label>
        &emsp;
        <label>City<input type="text" class="form-control" rows="5" name="ECity" id="ECity" value="<?php echo $__env->yieldContent('editECity'); ?>"></label>
        &emsp;
         <label>District<input type="text" class="form-control" rows="5" name="EDistrict" id="EDistrict" value="<?php echo $__env->yieldContent('editEDistrict'); ?>"></label>
        &emsp;
        <label>State<input type="text" class="form-control" rows="5" name="EState" id="EState" value="<?php echo $__env->yieldContent('editEState'); ?>"></label>
        &emsp;
        <label>PinCode<input type="text" class="form-control" rows="5" name="EPinCode" id="EPinCode" value="<?php echo $__env->yieldContent('editEPinCode'); ?>"></label>
     

        </div>
        </div>
        </div>



        </div>
        </div>
        </div>

       <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Patient Details</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">

        <label>Patient First Name<input type="text" class="form-control" rows="5" name="patientfname" id="patientfname" value="<?php echo $__env->yieldContent('editpatientfname'); ?>"></label>
        &emsp;
        <label>Middle Name<input type="text" class="form-control" rows="5" name="patientmname" id="patientmname" value="<?php echo $__env->yieldContent('editpatientmname'); ?>"></label>
        &emsp;
        <label>Last Name<input type="text" class="form-control" rows="5" name="patientlname" id="patientlname" value="<?php echo $__env->yieldContent('editpatientlname'); ?>"></label>
        &emsp;
        <label>Age <input type="text" class="form-control" rows="5" name="age" id="age" value="<?php echo $__env->yieldContent('editage'); ?>"></label>
        &emsp;
        <label>Gender
        <select name="gender" id="gender" class="form-control">
            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($gender->gendertypes); ?>"><?php echo e($gender->gendertypes); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select></label>
        &emsp;
        <label>Relationship
        <select name="relationship" id="relationship" class="form-control">
            <?php $__currentLoopData = $relation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($relation->relationshiptype); ?>"><?php echo e($relation->relationshiptype); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select></label>
        &emsp;
        <label>Occupation <input type="text" class="form-control" rows="5" name="Occupation" id="Occupation" value="<?php echo $__env->yieldContent('editOccupation'); ?>"></label>
        &emsp;
        <label>Aadhar Number <input type="text" class="form-control" rows="5" name="aadhar" id="aadhar" value="<?php echo $__env->yieldContent('editaadhar'); ?>"></label>
        &emsp;

       <label>Alternate UHID Type <input type="text" class="form-control" rows="5" name="AlternateUHIDType" id="AlternateUHIDType" value="<?php echo $__env->yieldContent('editAlternateUHIDType'); ?>"></label>
        &emsp;
        <label>Alternate UHID Number <input type="text" class="form-control" rows="5" name="AlternateUHIDNumber" id="AlternateUHIDNumber" value="<?php echo $__env->yieldContent('editAlternateUHIDNumber'); ?>"></label>
        &emsp;
        <label>Patient Aware of Disease <input type="text" class="form-control" rows="5" name="PTAwareofDisease" id="PTAwareofDisease" value="<?php echo $__env->yieldContent('editPTAwareofDisease'); ?>"></label>
        &emsp;
        </div>
        </div>
        </div>


         <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Service Details</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">

        <label>Service Type 
        <select name="servicetype" id="servicetype" class="form-control">
            <?php $__currentLoopData = $vertical; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vertical): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($vertical->servicetype); ?>"><?php echo e($vertical->servicetype); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        </label>
        &emsp;
        <label>General Condition 
          <select name="GeneralCondition" id="GeneralCondition" class="form-control">
            <?php $__currentLoopData = $condition; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($condition->conditiontypes); ?>"><?php echo e($condition->conditiontypes); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        </label>
        &emsp;
        <label>Lead Type 
        <select name="leadtype" id="leadtype" class="form-control">
            <?php $__currentLoopData = $leadtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leadtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($leadtype->leadtypes); ?>"><?php echo e($leadtype->leadtypes); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        </label>
        &emsp;
        <label>Branch <input type="text" class="form-control" rows="5" name="branch" id="branch" value="<?php echo $__env->yieldContent('editbranch'); ?>"></label>
        &emsp;
        <label>requested Date and Time <input type="date" class="form-control" rows="5" name="requesteddate" id="requesteddate" value="<?php echo $__env->yieldContent('editrequesteddate'); ?>"></label>
        &emsp;
        <label>Assigned TO 
          <select name="assignedto" id="assignedto" class="form-control">
            <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($emp->FirstName); ?>"><?php echo e($emp->FirstName); ?>  <?php echo e($emp->Designation); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        </label>
        &emsp;
        <label>Quoted Price <input type="text" class="form-control" rows="5" name="quotedprice" id="quotedprice" value="<?php echo $__env->yieldContent('editquotedprice'); ?>"></label>
        &emsp;
        <label>Expected Price <input type="text" class="form-control" rows="5" name="expectedprice" id="expectedprice" value="<?php echo $__env->yieldContent('editexpectedprice'); ?>"></label>
        &emsp;
        <label>Lead Status <input type="text" class="form-control" rows="5" name="servicestatus" id="servicestatus" value="<?php echo $__env->yieldContent('editservicestatus'); ?>"></label>
        &emsp;
        <label>Prefered Gender 
          <select name="preferedgender" id="preferedgender" class="form-control">
            <?php $__currentLoopData = $gender1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($gender1->gendertypes); ?>"><?php echo e($gender1->gendertypes); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        </label>
        &emsp;
        <label>Prefered Language 
          <select name="preferedlanguage" id="preferedlanguage" class="form-control">
            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($language->Languages); ?>"><?php echo e($language->Languages); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        </label>
        &emsp;
        <label>Remarks <textarea class="form-control" rows="5" name="remarks" id="remarks" value="<?php echo $__env->yieldContent('editremarks'); ?>"></textarea> </label>
        &emsp;

       
</div>
</div>
</div>

<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed12">Product Details</a>
        </h4>
      </div>
      <div id="collapsed12" class="panel-collapse collapse">
        <div class="panel-body">

              <label>SKU ID<input type="text" class="form-control" rows="5" name="SKUid" id="SKUid" value="<?php echo $__env->yieldContent('editSKUid'); ?>"></label>&emsp;

               <label>Product Name<input type="text" class="form-control" rows="5" name="ProductName" id="ProductName" value="<?php echo $__env->yieldContent('editProductName'); ?>"></label>&emsp;

                <label>Demo Required<input type="text" class="form-control" rows="5" name="DemoRequired" id="DemoRequired" value="<?php echo $__env->yieldContent('editDemoRequired'); ?>"></label>&emsp;

                 <label>Availability Status<input type="text" class="form-control" rows="5" name="AvailabilityStatus" id="AvailabilityStatus" value="<?php echo $__env->yieldContent('editAvailabilityStatus'); ?>"></label>
                 &emsp;
                  <label>Availability Address<input type="text" class="form-control" rows="5" name="AvailabilityAddress" id="AvailabilityAddress" value="<?php echo $__env->yieldContent('editAvailabilityAddress'); ?>"></label>
                  &emsp;
                   <label>Selling Price<input type="text" class="form-control" rows="5" name="SellingPrice" id="SellingPrice" value="<?php echo $__env->yieldContent('editSellingPrice'); ?>"></label>
                   &emsp;
                    <label>Rental Price<input type="text" class="form-control" rows="5" name="RentalPrice" id="RentalPrice" value="<?php echo $__env->yieldContent('editRentalPrice'); ?>"></label>
                    &emsp;
                     
        
        <br>
</div></div></div>
<?php $loginname=$_GET['name'];
?>

<input type="hidden" name="loginname" value="<?php echo $loginname;?>">

 <button type="submit" class="btn btn-success">Submit</button>
       </div>
     </div> 
    </div>
  </fieldset>
</form>
  <?php echo $__env->make('partial.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>


  <script>
$(function() {
    $('#country').on('change', function() {
        $('#phone').val($(this).val());
    });
});  </script>





</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>