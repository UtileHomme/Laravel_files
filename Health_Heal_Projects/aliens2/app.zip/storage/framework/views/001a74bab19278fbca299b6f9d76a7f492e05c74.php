<?php $__env->startSection('editid', $lead->id); ?>

<?php $__env->startSection('editassigned',$verc->FirstName); ?>


<?php $__env->startSection('editAssessor',$assessment->Assessor); ?>
<?php $__env->startSection('editAssessDateTime',$assessment->AssessDateTime); ?>
<?php $__env->startSection('editAssessPlace',$assessment->AssessPlace); ?>
<?php $__env->startSection('editServiceStartDate',$assessment->ServiceStartDate); ?>
<?php $__env->startSection('editServicePause',$assessment->ServicePause); ?>
<?php $__env->startSection('editServiceEndDate',$assessment->ServiceEndDate); ?>
<?php $__env->startSection('editShiftPreference',$assessment->ShiftPreference); ?>
<?php $__env->startSection('editSpecificRequirements',$assessment->SpecificRequirements); ?>
<?php $__env->startSection('editDaysWorked',$assessment->DaysWorked); ?>
<?php $__env->startSection('editLongitude',$assessment->Longitude); ?>
<?php $__env->startSection('editLatitude',$assessment->Latitude); ?>


<?php $__env->startSection('editInspection', $abdomen->Inspection); ?>
<?php $__env->startSection('editAusculationofBS', $abdomen->AusculationofBS); ?>
<?php $__env->startSection('editPalpation', $abdomen->Palpation); ?>
<?php $__env->startSection('editPercussion', $abdomen->Percussion); ?>
<?php $__env->startSection('editIleostomy', $abdomen->Ileostomy); ?>
<?php $__env->startSection('editColostomy', $abdomen->Colostomy); ?>
<?php $__env->startSection('editFunctioning', $abdomen->Functioning); ?>


<?php $__env->startSection('editChestPain', $circulatory->ChestPain); ?>
<?php $__env->startSection('edithoHTNCADCHF', $circulatory->hoHTNCADCHF); ?>
<?php $__env->startSection('editHR', $circulatory->HR); ?>
<?php $__env->startSection('editPeripheralCyanosis', $circulatory->PeripheralCyanosis); ?>
<?php $__env->startSection('editJugularVein', $circulatory->JugularVein); ?>
<?php $__env->startSection('editSurgeryHistory', $circulatory->SurgeryHistory); ?>


<?php $__env->startSection('editLanguage', $communication->Language); ?>
<?php $__env->startSection('editAdequateforAllActivities', $communication->AdequateforAllActivities); ?>
<?php $__env->startSection('editunableToCommunicate', $communication->unableToCommunicate); ?>


<?php $__env->startSection('editUpper', $denture->Upper); ?>
<?php $__env->startSection('editLower', $denture->Lower); ?>
<?php $__env->startSection('editCleaning', $denture->Cleaning); ?>


<?php $__env->startSection('editUppROM', $extremitie->UppROM); ?>
<?php $__env->startSection('editUppMuscleStrength', $extremitie->UppMuscleStrength); ?>
<?php $__env->startSection('editLowROM', $extremitie->LowROM); ?>
<?php $__env->startSection('editLowMuscleStrength', $extremitie->LowMuscleStrength); ?>


<?php $__env->startSection('editUrinaryContinent', $genito->UrinaryContinent); ?>
<?php $__env->startSection('editHoUTIPOSTTURP', $genito->HoUTIPOSTTURP); ?>
<?php $__env->startSection('editCompletelyContinet', $genito->CompletelyContinet); ?>
<?php $__env->startSection('editIncontinentUrineOccasionally', $genito->IncontinentUrineOccasionally); ?>
<?php $__env->startSection('editIncontinentUrineNightOnly', $genito->IncontinentUrineNightOnly); ?>
<?php $__env->startSection('editIncontinentUrineAlways', $genito->IncontinentUrineAlways); ?>


<?php $__env->startSection('editWeight', $generalcondition->Weight); ?>
<?php $__env->startSection('editHeight', $generalcondition->Height); ?>
<?php $__env->startSection('editMobility', $generalcondition->Mobility); ?>
<?php $__env->startSection('editUrinaryPattern', $generalcondition->UrinaryPattern); ?>
<?php $__env->startSection('editConsciousness', $generalcondition->Consciousness); ?>
<?php $__env->startSection('editMemoryIntact', $generalcondition->MemoryIntact); ?>
<?php $__env->startSection('editVision', $generalcondition->Vision); ?>
<?php $__env->startSection('editHearing', $generalcondition->Hearing); ?>
<?php $__env->startSection('editDiet', $generalcondition->Diet); ?>
<?php $__env->startSection('editMedicalHistory', $generalcondition->MedicalHistory); ?>


<?php $__env->startSection('editLongTermImpaired', $memoryintact->LongTermImpaired); ?>
<?php $__env->startSection('editShortTermImpaired', $memoryintact->ShortTermImpaired); ?>
<?php $__env->startSection('editLongTermIntact', $memoryintact->LongTermIntact); ?>
<?php $__env->startSection('editShortTermIntact', $memoryintact->ShortTermIntact); ?>


<?php $__env->startSection('editIndependent', $mobility->Independent); ?>
<?php $__env->startSection('editNeedAssistance', $mobility->NeedAssistance); ?>
<?php $__env->startSection('editWalker', $mobility->Walker); ?>
<?php $__env->startSection('editWheelChair', $mobility->WheelChair); ?>
<?php $__env->startSection('editCrutch', $mobility->Crutch); ?>
<?php $__env->startSection('editCane', $mobility->Cane); ?>
<?php $__env->startSection('editChairFast', $mobility->ChairFast); ?>
<?php $__env->startSection('editBedFast', $mobility->BedFast); ?>

<?php $__env->startSection('editPresentHistory', $generalhistory->PresentHistory); ?>
<?php $__env->startSection('editPastHistory', $generalhistory->PastHistory); ?>
<?php $__env->startSection('editFamilyHistory', $generalhistory->FamilyHistory); ?>
<?php $__env->startSection('editMensural_OBGHistory', $generalhistory->Mensural_OBGHistory); ?>
<?php $__env->startSection('editAllergicHistory', $generalhistory->AllergicHistory); ?>
<?php $__env->startSection('editAllergicStatus', $generalhistory->AllergicStatus); ?>
<?php $__env->startSection('editAllergicSeverity', $generalhistory->AllergicSeverity); ?>


<?php $__env->startSection('editAdequate', $nutrition->Adequate); ?>
<?php $__env->startSection('editDiet', $nutrition->Diet); ?>
<?php $__env->startSection('editBFTime', $nutrition->BFTime); ?>
<?php $__env->startSection('editLunchTime', $nutrition->LunchTime); ?>
<?php $__env->startSection('editSnacksTime', $nutrition->SnacksTime); ?>
<?php $__env->startSection('editDinnerTime', $nutrition->DinnerTime); ?>
<?php $__env->startSection('editTPN', $nutrition->TPN); ?>
<?php $__env->startSection('editRTFeeding', $nutrition->RTFeeding); ?>
<?php $__env->startSection('editPEGFeeding', $nutrition->PEGFeeding); ?>



<?php $__env->startSection('editPerson', $orientation->Person); ?>
<?php $__env->startSection('editPlace', $orientation->Place); ?>
<?php $__env->startSection('editTime', $orientation->Time); ?>


<?php $__env->startSection('editBP', $vitalsign->BP); ?>
<?php $__env->startSection('editRR', $vitalsign->RR); ?>
<?php $__env->startSection('editTemperature', $vitalsign->Temperature); ?>
<?php $__env->startSection('editTemperatureType', $vitalsign->TemperatureType); ?>
<?php $__env->startSection('editP1', $vitalsign->P1); ?>
<?php $__env->startSection('editP2', $vitalsign->P2); ?>
<?php $__env->startSection('editP3', $vitalsign->P3); ?>
<?php $__env->startSection('editR1', $vitalsign->R1); ?>
<?php $__env->startSection('editR2', $vitalsign->R2); ?>
<?php $__env->startSection('editR3', $vitalsign->R3); ?>
<?php $__env->startSection('editR4', $vitalsign->R4); ?>
<?php $__env->startSection('editT1', $vitalsign->T1); ?>
<?php $__env->startSection('editT2', $vitalsign->T2); ?>
<?php $__env->startSection('editPulse', $vitalsign->Pulse); ?>
<?php $__env->startSection('editPainScale', $vitalsign->PainScale); ?>
<?php $__env->startSection('editQuality', $vitalsign->Quality); ?>
<?php $__env->startSection('editSeverityScale', $vitalsign->SeverityScale); ?>



<?php $__env->startSection('editSOB', $respiratory->SOB); ?>
<?php $__env->startSection('editCough', $respiratory->Cough); ?>
<?php $__env->startSection('editColorOfPhlegm', $respiratory->ColorOfPhlegm); ?>
<?php $__env->startSection('editNebulization', $respiratory->Nebulization); ?>
<?php $__env->startSection('editTracheostomy', $respiratory->Tracheostomy); ?>
<?php $__env->startSection('editCPAP_BIPAP', $respiratory->CPAP_BIPAP); ?>
<?php $__env->startSection('editICD', $respiratory->ICD); ?>
<?php $__env->startSection('editPosition', $respiratory->Position); ?>
<?php $__env->startSection('editH_OTB_Asthma_COPD', $respiratory->H_OTB_Asthma_COPD); ?>
<?php $__env->startSection('editSPO2', $respiratory->SPO2); ?>



<?php $__env->startSection('editImpared', $visionhearing->Impared); ?>
<?php $__env->startSection('editShortSight', $visionhearing->ShortSight); ?>
<?php $__env->startSection('editLongSight', $visionhearing->LongSight); ?>
<?php $__env->startSection('editWearsGlasses', $visionhearing->WearsGlasses); ?>
<?php $__env->startSection('editHearingAids', $visionhearing->HearingAids); ?>

<?php $__env->startSection('editSKUid', $product->SKUid); ?>
<?php $__env->startSection('editProductName', $product->ProductName); ?>
<?php $__env->startSection('editDemoRequired', $product->DemoRequired); ?>
<?php $__env->startSection('editAvailabilityStatus', $product->AvailabilityStatus); ?>
<?php $__env->startSection('editAvailabilityAddress', $product->AvailabilityAddress); ?>
<?php $__env->startSection('editSellingPrice', $product->SellingPrice); ?>
<?php $__env->startSection('editRentalPrice', $product->RentalPrice); ?>




<?php $__env->startSection('editMethod'); ?>
<?php echo e(method_field('PUT')); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('verticalheads.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>