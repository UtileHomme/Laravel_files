;

<?php $__env->startSection('title','Gender'); ?>
<?php $__env->startSection('body'); ?>



<br>


<a href="/languages/create" class="btn btn-info">Add</a>
<div class="col-lg-6 col-lg-offset-3">
<center><h1>Language Details</h1></center>
<?php echo $__env->make('partial.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<ul class="list-group col-lg-15">
   <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="list-group-item">
  
	</br><?php echo e($language->id); ?>&emsp;
	   <?php echo e($language->Languages); ?>&emsp;
<div>
<a href="<?php echo e('/languages/'.$language->id.'/edit'); ?>">Edit</a>

<form action="<?php echo e('/languages/'.$language->id); ?>" method="post">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>

<input type="submit" value="Delete">
</form>

    </div>
    
    <br>
  </li>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>