<?php $__env->startSection('editid', $ptcondition->id); ?>
<?php $__env->startSection('editconditiontypes',$ptcondition->conditiontypes); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo e(method_field('PUT')); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('ptcondition.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>