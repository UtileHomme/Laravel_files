<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class memoryintact extends Model
{
    //
}
