<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class circulatory extends Model
{
    //
}
