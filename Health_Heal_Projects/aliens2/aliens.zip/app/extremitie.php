<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class extremitie extends Model
{
    //
}
