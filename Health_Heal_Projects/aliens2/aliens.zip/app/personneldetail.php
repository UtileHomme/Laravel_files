<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class personneldetail extends Model
{
    //
}
