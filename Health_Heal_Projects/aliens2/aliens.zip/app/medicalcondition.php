<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class medicalcondition extends Model
{
    //
}
