<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class verticalcoordination extends Model
{
    //
}
