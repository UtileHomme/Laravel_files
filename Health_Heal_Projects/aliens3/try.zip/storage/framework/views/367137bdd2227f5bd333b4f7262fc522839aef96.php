<?php $__env->startSection('editid', $gender->id); ?>
<?php $__env->startSection('editgendertypes',$gender->gendertypes); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo e(method_field('PUT')); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('gender.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>