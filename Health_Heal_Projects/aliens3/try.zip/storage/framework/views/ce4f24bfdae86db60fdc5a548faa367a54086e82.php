<?php $__env->startSection('editid', $reference->id); ?>
<?php $__env->startSection('editReference',$reference->Reference); ?>
<?php $__env->startSection('editReferalType',$reference->ReferalType); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo e(method_field('PUT')); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('reference.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>