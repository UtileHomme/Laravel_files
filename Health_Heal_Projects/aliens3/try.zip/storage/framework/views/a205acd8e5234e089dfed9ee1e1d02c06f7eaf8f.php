<?php $__env->startSection('body'); ?>
<br>
<a href="/references" class="btn btn-info" >Back</a>

<div class="col-lg-4 col-lg-offset-4">
<h1><?php echo e(substr(Route::currentRouteName(),13)); ?> item</h1>
<form class="form-horizontal" action="/references/<?php echo $__env->yieldContent('editid'); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo $__env->yieldSection(); ?>
  <fieldset>
    <div class="form-group">
    <div class="col-lg-10">
       <label>Reference<input type="text" class="form-control" rows="5" name="Reference" id="Reference" value="<?php echo $__env->yieldContent('editReference'); ?>"></label>
        <br>
        <label>Reference Type <input type="text" class="form-control" rows="5" name="ReferalType" id="ReferalType" value="<?php echo $__env->yieldContent('editReferalType'); ?>"></label>
        <br>
        <button type="submit" class="btn btn-success">Submit</button>
       </div>
    </div>
  </fieldset>
</form>
  <?php echo $__env->make('partial.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>