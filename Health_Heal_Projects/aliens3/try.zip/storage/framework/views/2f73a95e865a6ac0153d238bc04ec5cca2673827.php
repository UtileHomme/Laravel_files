;

<?php $__env->startSection('title','Gender'); ?>
<?php $__env->startSection('body'); ?>



<br>


<a href="/admin/vertical" class="btn btn-info">Home</a>
<div>
<center><h1>Leads list</h1></center>
<?php echo $__env->make('partial.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<table>
<tr>
	<td><b>S.no&emsp;</td>
  	<td><b>Lead No. &emsp;</td>
  	<td><b>Created Date&emsp;</td>
  	<td><b>Created By&emsp;&emsp;&emsp;&emsp;</td>
	<td><b> Client Name&emsp;</td>
	   <td><b>MobileNumber&emsp;</td>
	   <td><b>Email ID&emsp;</td>
	   <td><b>Source&emsp;</td>

	      <td><b>City&emsp;</td>
	      <td><b>Service Type&emsp;</td>
	      <td><b>Lead Type &emsp;</td>
	      <td><b>Status &emsp;</td>
</tr>
<tr><br><?php $i=1 ?></tr>
  <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<?php 
if(session()->has('name'))
{
	$name=session()->get('name');
}else
{
if(isset($_GET['name'])){
   $name=$_GET['name'];
}else{
   $name=NULL;
}
}
?>
  	<td><?php echo e($i++); ?></td>
  	<td><a href="/vh/create?id=<?php echo e($lead->id); ?>&name=<?php echo $name?>"><?php echo e($lead->id); ?></a>&emsp;&emsp;&emsp;&emsp;</td>
  	<td><?php echo e($lead->created_at); ?></td>
  	<td><?php echo e($lead->createdby); ?></td>
	<td><?php echo e($lead->fName); ?>&emsp;&emsp;</td>
	<td><?php echo e($lead->MobileNumber); ?>&emsp;&emsp;&emsp;</td>
	<td><?php echo e($lead->EmailId); ?>&emsp;</td>
	<td><?php echo e($lead->Source); ?>&emsp;</td>
	<td><?php echo e($lead->ServiceType); ?>&emsp;&emsp;</td>
	<td><?php echo e($lead->LeadType); ?>&emsp;&emsp;</td>
	<td><?php echo e($lead->ServiceStatus); ?>&emsp;</td>
	<td>
	<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($lead->id); ?>">More</a>
        </h4>
      </div>
    </td>
</tr>   
<tr>
<td colspan="12">

	
		<div id="<?php echo e($lead->id); ?>" class="panel-collapse collapse">
        <div class="panel-body" >
        <div style="text-align: left;">
	      <b>Alternate number:</b> <?php echo e($lead->Alternatenumber); ?>&emsp;
	      <b>Assessment Required: </b><?php echo e($lead->AssesmentReq); ?>&emsp;
	      <b>Patient Name:</b> <?php echo e($lead->PtfName); ?>&emsp;
	      <b>age:</b> <?php echo e($lead->age); ?>&emsp;&emsp;&emsp;
	      <b>Gender:</b> <?php echo e($lead->Gender); ?>&emsp;&emsp;</br></br>
	      <b>Realtionsip:</b> <?php echo e($lead->Relationship); ?>&emsp;
	      <b>Status:</b> <?php echo e($lead->Occupation); ?>&emsp;
<br><br>
<b>Permanent Address: </b><br><br>
	      <b>Address1: </b><?php echo e($lead->Address1); ?>

	      <b>Address2: </b><?php echo e($lead->Address2); ?>

	      <b>City: </b><?php echo e($lead->City); ?>

	      <b>District: </b><?php echo e($lead->District); ?>

	      <b>State: </b><?php echo e($lead->State); ?>

	      <b>Pincode: </b><?php echo e($lead->PinCode); ?>


	      <br><br>
	      <b>Emergency Address: </b><br><br>
	      <b>Address1: </b><?php echo e($lead->EAddress1); ?>

	      <b>Address2: </b><?php echo e($lead->EAddress2); ?>

	      <b>City: </b><?php echo e($lead->ECity); ?>

	      <b>District: </b><?php echo e($lead->EDistrict); ?>

	      <b>State: </b><?php echo e($lead->EState); ?>

	      <b>Pincode: </b><?php echo e($lead->EPinCode); ?>

<br><br>
	      <b>Aadhar number:</b> <?php echo e($lead->AadharNum); ?>&emsp;&emsp;
	      
	      <b>Service type:</b> <?php echo e($lead->ServiceType); ?>&emsp;&emsp;
	      <b>General Condition:</b> <?php echo e($lead->GeneralCondition); ?>&emsp;&emsp;</br></br>
	      <b>Branch:</b> <?php echo e($lead->Branch); ?>&emsp;
	      <b>Requested Date:</b> <?php echo e($lead->RequestDateTime); ?>&emsp;

	      <b>Assigned to:</b> <?php echo e($lead->AssignedTo); ?>&emsp;
	      
	      <b>Quoted Price:</b> &#8377; <?php echo e($lead->QuotedPrice); ?>&emsp;
	      <b>Expected Price:</b> &#8377; <?php echo e($lead->ExpectedPrice); ?>&emsp;</br></br>
	      <b>Service Status:</b> <?php echo e($lead->ServiceStatus); ?>&emsp;
	      <b>Gender Prefered:</b> <?php echo e($lead->PreferedGender); ?>&emsp;
	      <b>Prefered Languages:</b> <?php echo e($lead->PreferedLanguage); ?>&emsp;
	      <b>Remarks:</b> <?php echo e($lead->Remarks); ?>&emsp;
	      </div>
	    	<!-- <button><a href="<?php echo e('/cc/'.$lead->id.'/edit'); ?>">Edit &emsp;</a></button> -->
		</div>
		</div>
		</div>
		
	</td>
</tr>


<!-- 
<td>

<form action="<?php echo e('/cc/'.$lead->id); ?>" method="post">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>

<input type="submit" value="Delete">

</form>

    </td> -->
   <!--  </tr> -->

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>