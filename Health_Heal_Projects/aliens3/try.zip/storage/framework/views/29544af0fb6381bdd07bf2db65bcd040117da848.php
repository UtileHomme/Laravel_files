<?php $__env->startSection('body'); ?>
<br>
<a href="/admin/vertical" class="btn btn-info" >Home</a>


<h1><?php echo e(substr(Route::currentRouteName(),9)); ?> Assessment Form</h1>
<div class="container">
       <div class="panel-group" id="accordion">   
<form class="form-horizontal" action="/vh/<?php echo $__env->yieldContent('editid'); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo $__env->yieldSection(); ?>
  <fieldset>

    <div class="form-group">
 
<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse30">Lead Details</a>
        </h4>
      </div>
      <div id="collapse30" class="panel-collapse collapse">
        <div class="panel-body">
  <?php $__currentLoopData = $leaddata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <b>Lead ID : </b><?php echo e($lead->id); ?>&emsp;&emsp;
    <b>Created At : </b><?php echo e($lead->created_at); ?>&emsp;&emsp;
    <b>Created By : </b><?php echo e($lead->createdby); ?>&emsp;&emsp;
  <b>Client First Name : </b><?php echo e($lead->fName); ?>&emsp;&emsp;
  <b>Client Middle Name : </b><?php echo e($lead->mName); ?>&emsp;&emsp;
  <b>Client Last Name : </b><?php echo e($lead->lName); ?>&emsp;&emsp;
  <b>Client Mobile Number : </b><?php echo e($lead->MobileNumber); ?>&emsp;&emsp;
  <b>Email Id:</b><?php echo e($lead->EmailId); ?>&emsp;&emsp;
  <b>Source :</b><?php echo e($lead->Source); ?>&emsp;&emsp;
  <b>Service Type : </b><?php echo e($lead->ServiceType); ?>&emsp;&emsp;
  <b>Lead Type : </b><?php echo e($lead->LeadType); ?>&emsp;&emsp;
  <b>Service Status : </b><?php echo e($lead->ServiceStatus); ?>&emsp;&emsp;
        <b>Alternate number:</b> <?php echo e($lead->Alternatenumber); ?>&emsp;&emsp;
        <b>Assessment Required: </b><?php echo e($lead->AssesmentReq); ?>&emsp;&emsp;
        <b>Patient Name:</b> <?php echo e($lead->PtfName); ?>&emsp;&emsp;
        <b>age:</b> <?php echo e($lead->age); ?>&emsp;&emsp;
        <b>Gender:</b> <?php echo e($lead->Gender); ?>&emsp;&emsp;
        <b>Realtionsip:</b> <?php echo e($lead->Relationship); ?>&emsp;&emsp;
        <b>Status:</b> <?php echo e($lead->Occupation); ?>&emsp;&emsp;

        <b>Aadhar number:</b> <?php echo e($lead->AadharNum); ?>&emsp;&emsp;
        
        <b>Service type:</b> <?php echo e($lead->ServiceType); ?>&emsp;&emsp;
        <b>General Condition:</b> <?php echo e($lead->GeneralCondition); ?>&emsp;&emsp;
        <b>Branch:</b> <?php echo e($lead->Branch); ?>&emsp;&emsp;
        <b>Requested Date:</b> <?php echo e($lead->RequestDateTime); ?>&emsp;&emsp;

        <b>Assigned to:</b> <?php echo e($lead->AssignedTo); ?>&emsp;&emsp;
        
        <b>Quoted Price:</b> &#8377; <?php echo e($lead->QuotedPrice); ?>&emsp;&emsp;
        <b>Expected Price:</b> &#8377; <?php echo e($lead->ExpectedPrice); ?>&emsp;&emsp;
        <b>Service Status:</b> <?php echo e($lead->ServiceStatus); ?>&emsp;&emsp;
        <b>Gender Prefered:</b> <?php echo e($lead->PreferedGender); ?>&emsp;&emsp;
        <b>Prefered Languages:</b> <?php echo e($lead->PreferedLanguage); ?>&emsp;&emsp;
        <b>Remarks:</b> <?php echo e($lead->Remarks); ?>&emsp;&emsp;
        
        <!-- <button><a href="<?php echo e('/cc/'.$lead->id.'/edit'); ?>">Edit &emsp;</a></button> -->
   
<br><br>
    <label>Assign TO
            <select name="assigned" id="assigned" class="form-control" >
             <option value="<?php echo $__env->yieldContent('editassigned'); ?>"><?php echo $__env->yieldContent('editassigned'); ?></option>

            <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($emp->FirstName); ?>"><?php echo e($emp->FirstName); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
              </label>&emsp;

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>
            <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed11">General Details</a>
        </h4>
      </div>
      <div id="collapsed11" class="panel-collapse collapse">
        <div class="panel-body">

              <label>Assessor<input type="text" class="form-control" rows="5" name="Assessor" id="Assessor" value="<?php echo $__env->yieldContent('editAssessor'); ?>"></label>&emsp;

               <label>Assess DateTime<input type="datetime-local" class="form-control" rows="5" name="AssessDateTime" id="AssessDateTime" value="<?php echo $__env->yieldContent('editAssessDateTime'); ?>">
               </label>&emsp;

                <label>Assess Place<input type="text" class="form-control" rows="5" name="AssessPlace" id="AssessPlace" value="<?php echo $__env->yieldContent('editAssessPlace'); ?>"></label>&emsp;

                 <label>Service Start Date<input type="date" class="form-control" rows="5" name="ServiceStartDate" id="ServiceStartDate" value="<?php echo $__env->yieldContent('editServiceStartDate'); ?>"></label>
                 &emsp;
                  <label>Service Pause<input type="text" class="form-control" rows="5" name="ServicePause" id="ServicePause" value="<?php echo $__env->yieldContent('editServicePause'); ?>"></label>
                  &emsp;
                   <label>Service End Date<input type="date" class="form-control" rows="5" name="ServiceEndDate" id="ServiceEndDate" value="<?php echo $__env->yieldContent('editServiceEndDate'); ?>"></label>
                   &emsp;
                    <label>Shift Preference<input type="text" class="form-control" rows="5" name="ShiftPreference" id="ShiftPreference" value="<?php echo $__env->yieldContent('editShiftPreference'); ?>"></label>
                    &emsp;
                     <label>Specific Requirements<input type="text" class="form-control" rows="5" name="SpecificRequirements" id="SpecificRequirements" value="<?php echo $__env->yieldContent('editSpecificRequirements'); ?>"></label>
                     &emsp;
                   <label>Days Worked<input type="text" class="form-control" rows="5" name="DaysWorked" id="DaysWorked" value="<?php echo $__env->yieldContent('editDaysWorked'); ?>"></label>&emsp;

                   <label>Latitude<input type="text" class="form-control" rows="5" name="Latitude" id="Latitude" value="<?php echo $__env->yieldContent('editLatitude'); ?>"></label>&emsp;


                   <label>Longitude<input type="text" class="form-control" rows="5" name="Longitude" id="Longitude" value="<?php echo $__env->yieldContent('editLongitude'); ?>"></label>
                    
        &emsp;
        
        <br>
</div>
</div>
</div>
<br>






      <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed2">Assessment Details</a>
        </h4>
      </div>
      <div id="collapsed2" class="panel-collapse collapse">
        <div class="panel-body">

   <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Abdomen Details</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">

       <label>Inspection<input type="text" class="form-control" rows="5" name="Inspection" id="Inspection" value="<?php echo $__env->yieldContent('editInspection'); ?>"></label>
        &emsp;
        <label>Ausculation of Bowel Sound

        <!-- $title = app()->view->getSections()['title']; -->

        
             <select name="AusculationofBS" id="AusculationofBS" class="form-control" >
             <option value="<?php echo $__env->yieldContent('editAusculationofBS'); ?>"><?php echo $__env->yieldContent('editAusculationofBS'); ?></option>

            <option value="Absent" >Absent</option>
            <option value="Present">Present</option>
          </select>
        </label>
        &emsp;
        <label>Palpation <input type="text" class="form-control" rows="5" name="Palpation" id="Palpation" value="<?php echo $__env->yieldContent('editPalpation'); ?>"></label>
        &emsp;
        <label>Percussion <input type="text" class="form-control" rows="5" name="Percussion" id="Percussion" value="<?php echo $__env->yieldContent('editPercussion'); ?>"></label>
        <br>
        <label>Ileostomy 
             <select name="Ileostomy" id="Ileostomy" class="form-control" value="<?php echo $__env->yieldContent('editIleostomy'); ?>">
             <option value="<?php echo $__env->yieldContent('editIleostomy'); ?>"><?php echo $__env->yieldContent('editIleostomy'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Colostomy 
            <select name="Colostomy" id="Colostomy" class="form-control" value="<?php echo $__env->yieldContent('editColostomy'); ?>">
             <option value="<?php echo $__env->yieldContent('editColostomy'); ?>"><?php echo $__env->yieldContent('editColostomy'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Functioning 
            <select name="Functioning" id="Functioning" class="form-control" value="<?php echo $__env->yieldContent('editFunctioning'); ?>">
             <option value="<?php echo $__env->yieldContent('editFunctioning'); ?>"><?php echo $__env->yieldContent('editFunctioning'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        <br>
        
        <br>
        </div>
        </div>
        </div>



<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Circulatory Details</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
        <label>Chest Pain<input type="text" class="form-control" rows="5" name="ChestPain" id="ChestPain" value="<?php echo $__env->yieldContent('editChestPain'); ?>"></label>
        &emsp;
        <label>H/O HTN/CAD/CHF <input type="text" class="form-control" rows="5" name="hoHTNCADCHF" id="hoHTNCADCHF" value="<?php echo $__env->yieldContent('edithoHTNCADCHF'); ?>"></label>
        &emsp;
        <label>Heart Rate<input type="text" class="form-control" rows="5" name="HR" id="HR" value="<?php echo $__env->yieldContent('editHR'); ?>"></label>
        &emsp;
        <label>Peripheral Cyanosis
        <select name="PeripheralCyanosis" id="PeripheralCyanosis" class="form-control" value="<?php echo $__env->yieldContent('editPeripheralCyanosis'); ?>">
            <option value="<?php echo $__env->yieldContent('editPeripheralCyanosis'); ?>"><?php echo $__env->yieldContent('editPeripheralCyanosis'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select></label>
        <br>
        <label>Jugular Vein
          <select name="JugularVein" id="JugularVein" class="form-control" value="<?php echo $__env->yieldContent('editJugularVein'); ?>">
            <option value="<?php echo $__env->yieldContent('editJugularVein'); ?>"><?php echo $__env->yieldContent('editJugularVein'); ?></option>
            <option value="Flat">Flat</option>
            <option value="Distended">Distended</option>
          </select>

        </label>
        &emsp;
        <label>Surgery History <input type="text" class="form-control" rows="5" name="SurgeryHistory" id="SurgeryHistory" value="<?php echo $__env->yieldContent('editSurgeryHistory'); ?>"></label>
        <br>
      </div>  
      </div>
</div>

        <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Communication Details</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <div class="panel-body">
        <label>Language 
            <select name="Language" id="Language" class="form-control">
            <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($language->Languages); ?>"><?php echo e($language->Languages); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>

        </label>
        &emsp;
        <label>Adequate for All Activities
            <select name="AdequateforAllActivities" id="AdequateforAllActivities" class="form-control" value="<?php echo $__env->yieldContent('editAdequateforAllActivities'); ?>">
            <option value="<?php echo $__env->yieldContent('editAdequateforAllActivities'); ?>"><?php echo $__env->yieldContent('editAdequateforAllActivities'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Unable To Communicate
            <select name="unableToCommunicate" id="unableToCommunicate" class="form-control" value="<?php echo $__env->yieldContent('editunableToCommunicate'); ?>">
            <option value="<?php echo $__env->yieldContent('editunableToCommunicate'); ?>"><?php echo $__env->yieldContent('editunableToCommunicate'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
   </div>    
   </div>
</div>



 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Denture Details</a>
        </h4>
      </div>
      <div id="collapse4" class="panel-collapse collapse">
        <div class="panel-body">

    
        <label>Upper 
            <select name="Upper" id="Upper" class="form-control" value="<?php echo $__env->yieldContent('editUpper'); ?>">
            <option value="<?php echo $__env->yieldContent('editUpper'); ?>"><?php echo $__env->yieldContent('editUpper'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Lower
        <select name="Lower" id="Lower" class="form-control" value="<?php echo $__env->yieldContent('editLower'); ?>">
        <option value="<?php echo $__env->yieldContent('editLower'); ?>"><?php echo $__env->yieldContent('editLower'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Need assistance in cleaning
            <select name="Cleaning" id="Cleaning" class="form-control" value="<?php echo $__env->yieldContent('editCleaning'); ?>">
            <option value="<?php echo $__env->yieldContent('editCleaning'); ?>"><?php echo $__env->yieldContent('editCleaning'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
   </div>
   </div>    
</div>



 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse5">Extremities Detail</a>
        </h4>
      </div>
      <div id="collapse5" class="panel-collapse collapse">
        <div class="panel-body">
        <label>Upper Extremities ROM 
            <select name="UppROM" id="UppROM" class="form-control" value="<?php echo $__env->yieldContent('editUppROM'); ?>">
            <option value="<?php echo $__env->yieldContent('editUppROM'); ?>"><?php echo $__env->yieldContent('editUppROM'); ?></option>
            <option value="Limited">Limited</option>
            <option value="Restricted">Restricted</option>
          </select>
        </label>
        &emsp;
        <label>Upper Muscle Strength
            <select name="UppMuscleStrength" id="UppMuscleStrength" class="form-control" value="<?php echo $__env->yieldContent('editUppMuscleStrength'); ?>">
            <option value="<?php echo $__env->yieldContent('editUppMuscleStrength'); ?>"><?php echo $__env->yieldContent('editUppMuscleStrength'); ?></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
        </label>
        &emsp;
       
        <label>Lower Extremities ROM
            <select name="LowROM" id="LowROM" class="form-control" value="<?php echo $__env->yieldContent('editLowROM'); ?>">
            <option value="<?php echo $__env->yieldContent('editLowROM'); ?>"><?php echo $__env->yieldContent('editLowROM'); ?></option>
            <option value="Limited">Limited</option>
            <option value="Restricted">Restricted</option>
          </select>
        </label>
        &emsp;
        <label>Lower Muscle Strength
            <select name="LowMuscleStrength" id="LowMuscleStrength" class="form-control" value="<?php echo $__env->yieldContent('editLowMuscleStrength'); ?>">
            <option value="<?php echo $__env->yieldContent('editLowMuscleStrength'); ?>"><?php echo $__env->yieldContent('editLowMuscleStrength'); ?></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            
          </select>
        </label>
        &emsp;
   </div>   
   </div> 
</div>


 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse6">Genitos Urinary</a>
        </h4>
      </div>
      <div id="collapse6" class="panel-collapse collapse">
        <div class="panel-body">


        <label>Urinary Continent <input type="text" class="form-control" rows="5" name="UrinaryContinent" id="UrinaryContinent" value="<?php echo $__env->yieldContent('editUrinaryContinent'); ?>"></label>
        &emsp;
        <label>H/O UTI/POSTTURP<input type="text" class="form-control" rows="5" name="HoUTIPOSTTURP" id="HoUTIPOSTTURP" value="<?php echo $__env->yieldContent('editHoUTIPOSTTURP'); ?>"></label>
        &emsp;
        <label>Completely Continet

        <select name="CompletelyContinet" id="CompletelyContinet" class="form-control" value="<?php echo $__env->yieldContent('editCompletelyContinet'); ?>">
            <option value="<?php echo $__env->yieldContent('editCompletelyContinet'); ?>"><?php echo $__env->yieldContent('editCompletelyContinet'); ?></option>
            <option value="Indepentdent">Indepentdent</option>
            <option value="Urinal/Bedpan">Urinal/Bedpan</option>
            <option value="BathroomRoutine">BathroomRoutine</option>
          </select>
        </label>
        &emsp;
        <br>
        <label>Incontinent Urine Occasionally
          <select name="IncontinentUrineOccasionally" id="IncontinentUrineOccasionally" class="form-control" value="<?php echo $__env->yieldContent('editIncontinentUrineOccasionally'); ?>">
            <option value="<?php echo $__env->yieldContent('editIncontinentUrineOccasionally'); ?>"><?php echo $__env->yieldContent('editIncontinentUrineOccasionally'); ?></option>
            <option value="Assistance">Assistance</option>
            <option value="Daiper/Breifs">Daiper/Breifs</option>
          </select>

        </label>
        &emsp;

        <label>Incontinent Urine Night Only

          <select name="IncontinentUrineNightOnly" id="IncontinentUrineNightOnly" class="form-control" value="<?php echo $__env->yieldContent('editIncontinentUrineNightOnly'); ?>">
            <option value="<?php echo $__env->yieldContent('editIncontinentUrineNightOnly'); ?>"><?php echo $__env->yieldContent('editIncontinentUrineNightOnly'); ?></option>
            <option value="Assistance">Assistance</option>
            <option value="Soaking pad and Diaper">Soaking pad and Diaper</option>
          </select>
        </label>
        &emsp;


        <label>Incontinent Urine Always

        <select name="IncontinentUrineAlways" id="IncontinentUrineAlways" class="form-control" value="<?php echo $__env->yieldContent('editIncontinentUrineAlways'); ?>">
            <option value="<?php echo $__env->yieldContent('editIncontinentUrineAlways'); ?>"><?php echo $__env->yieldContent('editIncontinentUrineAlways'); ?></option>
            <option value="Condom Catheter">Condom Catheter</option>
            <option value="Catheter">Catheter</option>
          </select>
        </label>
        &emsp;
   </div>   
   </div> 
</div>



<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse19">General Condition Details</a>
        </h4>
      </div>
      <div id="collapse19" class="panel-collapse collapse">
        <div class="panel-body">
       <label>Weight<input type="text" class="form-control" rows="5" name="Weight" id="Weight" value="<?php echo $__env->yieldContent('editWeight'); ?>"></label>
        &emsp;
        <label>Height
             <input type="text" class="form-control" rows="5" name="Height" id="Height" value="<?php echo $__env->yieldContent('editHeight'); ?>"></label>
        
        &emsp;
        <label>Mobility <input type="text" class="form-control" rows="5" name="Mobility" id="Mobility" value="<?php echo $__env->yieldContent('editMobility'); ?>"></label>
        &emsp;
        
        <label>Vision <input type="text" class="form-control" rows="5" name="Vision" id="Vision" value="<?php echo $__env->yieldContent('editVision'); ?>"></label>
        &emsp;
        <label>Hearing <input type="text" class="form-control" rows="5" name="Hearing" id="Hearing" value="<?php echo $__env->yieldContent('editHearing'); ?>"></label>
        &emsp;
       
        <label>MedicalHistory <input type="text" class="form-control" rows="5" name="MedicalHistory" id="MedicalHistory" value="<?php echo $__env->yieldContent('editMedicalHistory'); ?>"></label>
        &emsp;

      
        <br>
        
        <br>
        </div>
        </div>
        </div>

<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1000">General History</a>
        </h4>
      </div>
      <div id="collapse1000" class="panel-collapse collapse">
        <div class="panel-body">

        <label>Present History <input type="text" class="form-control" rows="5" name="PresentHistory" id="PresentHistory" value="<?php echo $__env->yieldContent('editPresentHistory'); ?>"></label>
        &emsp;
        <label>Past History <input type="text" class="form-control" rows="5" name="PastHistory" id="PastHistory" value="<?php echo $__env->yieldContent('editPastHistory'); ?>"></label>
        &emsp;
        <label>Family History <input type="text" class="form-control" rows="5" name="FamilyHistory" id="FamilyHistory" value="<?php echo $__env->yieldContent('editFamilyHistory'); ?>"></label>
        &emsp;
        <label>Mensuration & OBG History <input type="text" class="form-control" rows="5" name="Mensural_OBGHistory" id="Mensural_OBGHistory" value="<?php echo $__env->yieldContent('editMensural_OBGHistory'); ?>"></label>
        &emsp;
        <label>Allergic History <input type="text" class="form-control" rows="5" name="AllergicHistory" id="AllergicHistory" value="<?php echo $__env->yieldContent('editAllergicHistory'); ?>"></label>
        &emsp;
        <label>Allergic Status <input type="text" class="form-control" rows="5" name="AllergicStatus" id="AllergicStatus" value="<?php echo $__env->yieldContent('editAllergicStatus'); ?>"></label>
        &emsp;
        <label>Allergic Severity <input type="text" class="form-control" rows="5" name="AllergicSeverity" id="AllergicSeverity" value="<?php echo $__env->yieldContent('editAllergicSeverity'); ?>"></label>
        &emsp;

      
        <br>
        
        <br>
        </div>
        </div>
        </div>









<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse7">Memory Intacts Details</a>
        </h4>
      </div>
      <div id="collapse7" class="panel-collapse collapse">
        <div class="panel-body">
        <div>
        <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse60">Short Term</a>
        </h4>
      </div>
      <div id="collapse60" class="panel-collapse collapse">
        <div class="panel-body">
        <label>Intact 
        <select name="ShortTermIntact" id="ShortTermIntact" class="form-control" value="<?php echo $__env->yieldContent('editShortTermIntact'); ?>">
        <option value="<?php echo $__env->yieldContent('editShortTermIntact'); ?>"><?php echo $__env->yieldContent('editShortTermIntact'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select></label>
        &emsp;
        <label>Impaired
            <select name="ShortTermImpaired" id="ShortTermImpaired" class="form-control" value="<?php echo $__env->yieldContent('editShortTermImpaired'); ?>">
            <option value="<?php echo $__env->yieldContent('editShortTermImpaired'); ?>"><?php echo $__env->yieldContent('editShortTermImpaired'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        
   </div>    
   </div>
</div>
 &emsp; &emsp;
        </div>
        <div>
        <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse70">Long term</a>
        </h4>
      </div>
      <div id="collapse70" class="panel-collapse collapse">
        <div class="panel-body">
        <label>Intact
        <select name="LongTermIntact" id="LongTermIntact" class="form-control" value="<?php echo $__env->yieldContent('editLongTermIntact'); ?>">
        <option value="<?php echo $__env->yieldContent('editLongTermIntact'); ?>"><?php echo $__env->yieldContent('editLongTermIntact'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select></label>
        &emsp;
        <label>Impaired
            <select name="LongTermImpaired" id="LongTermImpaired" class="form-control" value="<?php echo $__env->yieldContent('editLongTermImpaired'); ?>">
            <option value="<?php echo $__env->yieldContent('editLongTermImpaired'); ?>"><?php echo $__env->yieldContent('editLongTermImpaired'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        
   </div>    
   </div>
</div>

        </div>
        
   </div>    
   </div>
</div>



 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse8">Mobility Details</a>
        </h4>
      </div>
      <div id="collapse8" class="panel-collapse collapse">
        <div class="panel-body">
        

        <label>Independent
        <select name="Independent" id="Independent" class="form-control" value="<?php echo $__env->yieldContent('editIndependent'); ?>">
        <option value="<?php echo $__env->yieldContent('editIndependent'); ?>"><?php echo $__env->yieldContent('editIndependent'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;

        <label>Need Assistance
        <select name="NeedAssistance" id="NeedAssistance" class="form-control" value="<?php echo $__env->yieldContent('editNeedAssistance'); ?>">
        <option value="<?php echo $__env->yieldContent('editNeedAssistance'); ?>"><?php echo $__env->yieldContent('editNeedAssistance'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Walker
        <select name="Walker" id="Walker" class="form-control" value="<?php echo $__env->yieldContent('editWalker'); ?>">
        <option value="<?php echo $__env->yieldContent('editWalker'); ?>"><?php echo $__env->yieldContent('editWalker'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        <label>WheelChair 
            <select name="WheelChair" id="WheelChair" class="form-control" value="<?php echo $__env->yieldContent('editWheelChair'); ?>">
            <option value="<?php echo $__env->yieldContent('editWheelChair'); ?>"><?php echo $__env->yieldContent('editWheelChair'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Crutch
            <select name="Crutch" id="Crutch" class="form-control" value="<?php echo $__env->yieldContent('editCrutch'); ?>">
            <option value="<?php echo $__env->yieldContent('editCrutch'); ?>"><?php echo $__env->yieldContent('editCrutch'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
      
        <label>Cane 
        <select name="Cane" id="Cane" class="form-control" value="<?php echo $__env->yieldContent('editCane'); ?>">
        <option value="<?php echo $__env->yieldContent('editCane'); ?>"><?php echo $__env->yieldContent('editCane'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
       
      <label>Chair Fast
 
        <select name="ChairFast" id="ChairFast" class="form-control" value="<?php echo $__env->yieldContent('editChairFast'); ?>">
        <option value="<?php echo $__env->yieldContent('editChairFast'); ?>"><?php echo $__env->yieldContent('editChairFast'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Bed Fast 
        <select name="BedFast" id="BedFast" class="form-control" value="<?php echo $__env->yieldContent('editBedFast'); ?>">
        <option value="<?php echo $__env->yieldContent('editBedFast'); ?>"><?php echo $__env->yieldContent('editBedFast'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;

   </div>    
   </div>
</div>


 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse9">Nutrition Details</a>
        </h4>
      </div>
      <div id="collapse9" class="panel-collapse collapse">
        <div class="panel-body">

        <label>Need Assistance Adequate<input type="text" class="form-control" rows="5" name="Adequate" id="Adequate" value="<?php echo $__env->yieldContent('editAdequate'); ?>"></label>
        &emsp;
        <label>Diet 
        <select name="Diet" id="Diet" class="form-control" value="<?php echo $__env->yieldContent('editDiet'); ?>">
        <option value="<?php echo $__env->yieldContent('editDiet'); ?>"><?php echo $__env->yieldContent('editDiet'); ?></option>
            <option value="Bland">Bland</option>
            <option value="Minced">Minced</option>
            <option value="Liquid">Liquid</option>
            <option value="Diabetic">Diabetic</option>
            <option value="Salt Restricted">Salt Restricted</option>
            <option value="Protein Restricted">Protein Restricted</option>
            <option value="Fat Free">Fat Free</option>
            <option value="NBM">NBM</option>
          </select>

        </label>
        &emsp;
        <label>BF Time<input type="text" class="form-control" rows="5" name="BFTime" id="BFTime" value="<?php echo $__env->yieldContent('editBFTime'); ?>"></label>
        &emsp;
        <br>
        <label>Lunch Time <input type="text" class="form-control" rows="5" name="LunchTime" id="LunchTime" value="<?php echo $__env->yieldContent('editLunchTime'); ?>"></label>
        &emsp;
         <label>Snacks Time <input type="text" class="form-control" rows="5" name="SnacksTime" id="SnacksTime" value="<?php echo $__env->yieldContent('editSnacksTime'); ?>"></label>
        &emsp;
        <label>Dinner Time<input type="text" class="form-control" rows="5" name="DinnerTime" id="DinnerTime" value="<?php echo $__env->yieldContent('editDinnerTime'); ?>"></label>
        &emsp;
        <label>TPN<input type="text" class="form-control" rows="5" name="TPN" id="TPN" value="<?php echo $__env->yieldContent('editTPN'); ?>"></label>
        <label>RT Feeding <input type="text" class="form-control" rows="5" name="RTFeeding" id="RTFeeding" value="<?php echo $__env->yieldContent('editRTFeeding'); ?>"></label>
        &emsp;
        <label>PEG Feeding<input type="text" class="form-control" rows="5" name="PEGFeeding" id="PEGFeeding" value="<?php echo $__env->yieldContent('editPEGFeeding'); ?>"></label>
        &emsp;
        
        
    </div>    
   </div>    
</div>


 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse10">Orientation Details</a>
        </h4>
      </div>
      <div id="collapse10" class="panel-collapse collapse">
        <div class="panel-body">
        <label>Person <input type="text" class="form-control" rows="5" name="Person" id="Person" value="<?php echo $__env->yieldContent('editPerson'); ?>"></label>
        &emsp;
        <label>Place <input type="text" class="form-control" rows="5" name="Place" id="Place" value="<?php echo $__env->yieldContent('editPlace'); ?>"></label>
        &emsp;
        <label>Time<input type="text" class="form-control" rows="5" name="Time" id="Time" value="<?php echo $__env->yieldContent('editTime'); ?>"></label>
        &emsp;
        
   </div>  
   </div>  
</div>



 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse11">Vital Signs</a>
        </h4>
      </div>
      <div id="collapse11" class="panel-collapse collapse">
        <div class="panel-body">


        <label>BP <input type="text" class="form-control" rows="5" name="BP" id="BP" value="<?php echo $__env->yieldContent('editBP'); ?>"></label>
        &emsp;
        <label>RR <input type="text" class="form-control" rows="5" name="RR" id="RR" value="<?php echo $__env->yieldContent('editRR'); ?>"></label>
        &emsp;
        <label>Temperature <input type="text" class="form-control" rows="5" name="Temperature" id="Temperature" value="<?php echo $__env->yieldContent('editTemperature'); ?>"></label>
        &emsp;
        <label>TemperatureType <input type="text" class="form-control" rows="5"  name="TemperatureType" id="TemperatureType" value="<?php echo $__env->yieldContent('editTemperatureType'); ?>"></label>
        &emsp;
        <br><br>
        <label>Provocation</label><br><br>
        <label>What causes pain?  <textarea class="form-control" rows="5" cols="20" name="P1" id="P1" value="<?php echo $__env->yieldContent('editP1'); ?>"></textarea></label>
        &emsp;
        <label>What makes it better? <textarea class="form-control" rows="5" cols="20" name="P2" id="P2" value="<?php echo $__env->yieldContent('editP2'); ?>"></textarea></label>
        &emsp;
        <label>Worse? <textarea class="form-control" rows="5" cols="20" name="P3" id="P3" value="<?php echo $__env->yieldContent('editP3'); ?>"></textarea></label>
        &emsp;
        <br><br>
        <label>Region</label><br><br>
        <label>Where does the pain radiate? <textarea class="form-control" rows="5" cols="20" name="R1" id="R1" value="<?php echo $__env->yieldContent('editR1'); ?>"></textarea></label>
        &emsp;
        <label>Is it in one place? <textarea class="form-control" rows="5" cols="20" name="R2" id="R2" value="<?php echo $__env->yieldContent('editR2'); ?>"></textarea></label>
        &emsp;
        <label>Does it go anywhere else? <textarea class="form-control" rows="5" cols="20" name="R3" id="R3" value="<?php echo $__env->yieldContent('editR3'); ?>"></textarea></label>
        &emsp;
        <label>Did it start elsewhere and now localised to one spot? <textarea  class="form-control" rows="5" cols="20" name="R4" id="R4" value="<?php echo $__env->yieldContent('editR4'); ?>"></textarea></label>
        &emsp;
        <br><br>
        <label>Timing</label><br><br>
        <label>Time pain started? <textarea class="form-control" rows="5" cols="20" name="T1" id="T1" value="<?php echo $__env->yieldContent('editT1'); ?>"></textarea></label>
        &emsp;
        <label>How long did it last? <textarea class="form-control" rows="5" cols="20" name="T2" id="T2" value="<?php echo $__env->yieldContent('editT2'); ?>"></textarea></label>
        &emsp;

        <br><br>
        <label>Pulse <input type="text" class="form-control" rows="5" cols="20" name="Pulse" id="Pulse" value="<?php echo $__env->yieldContent('editPulse'); ?>"></label>
        &emsp;

        <label>Quality 
        <select name="Quality" id="Quality" class="form-control" value="<?php echo $__env->yieldContent('editQuality'); ?>">
      <option value="<?php echo $__env->yieldContent('editQuality'); ?>"><?php echo $__env->yieldContent('editQuality'); ?></option>
            <option value="Sharp">Sharp</option>
            <option value="Dull">Dull</option>
            <option value="Stabbing">Stabbing</option>
            <option value="Burning">Burning</option>
            <option value="Crushing">Crushing</option>
          </select>

        </label>
        &emsp;

          <label>Pain Scale 
        <select name="PainScale" id="PainScale" class="form-control" value="<?php echo $__env->yieldContent('editPainScale'); ?>">
      <option value="<?php echo $__env->yieldContent('editPainScale'); ?>"><?php echo $__env->yieldContent('editPainScale'); ?></option>
            <option value="Face Reading Scale ">Face Reading Scale </option>
            <option value="Numeric Reading Scale">Numeric Reading Scale</option>
          </select>
        </label>
        &emsp;

        <label>Severity Scale 
          <select name="SeverityScale" id="SeverityScale" class="form-control" value="<?php echo $__env->yieldContent('editSeverityScale'); ?>">
      <option value="<?php echo $__env->yieldContent('editSeverityScale'); ?>"><?php echo $__env->yieldContent('editSeverityScale'); ?></option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
          </select>
        </label>
        &emsp;
        
        </div>
   </div>    
</div>



 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse12">Respiratory Details</a>
        </h4>
      </div>
      <div id="collapse12" class="panel-collapse collapse">
        <div class="panel-body">

        <label>SOB <input type="text" class="form-control" rows="5" name="SOB" id="SOB" value="<?php echo $__env->yieldContent('editSOB'); ?>"></label>
        &emsp;

        <label>SPO2 <input type="text" class="form-control" rows="5" name="SPO2" id="SPO2" value="<?php echo $__env->yieldContent('editSPO2'); ?>"></label>
        &emsp;

        <label>H_OTB_Asthma_COPD <input type="text" class="form-control" rows="5" name="H_OTB_Asthma_COPD" id="H_OTB_Asthma_COPD" value="<?php echo $__env->yieldContent('editH_OTB_Asthma_COPD'); ?>"></label>
        &emsp;
        
        <label>Cough
            <select name="Cough" id="Cough" class="form-control" value="<?php echo $__env->yieldContent('editCough'); ?>">
            <option value="<?php echo $__env->yieldContent('editCough'); ?>"><?php echo $__env->yieldContent('editCough'); ?></option>
            <option value="Productive">Productive</option>
            <option value="Non-Productive">Non-Productive</option>
            <option value="Productive(Dry)">Productive(Dry)</option>
            <option value="Non-Productive(Dry)">Non-Productive(Dry)</option>
          </select>
        </label>
        &emsp;
        <label>Color Of Phlegm <input type="text" class="form-control" rows="5" name="ColorOfPhlegm" id="ColorOfPhlegm" value="<?php echo $__env->yieldContent('editColorOfPhlegm'); ?>"></label>
        &emsp;
        <br>
        <label>Nebulization
<select name="Nebulization" id="Nebulization" class="form-control" value="<?php echo $__env->yieldContent('editNebulization'); ?>">
      <option value="<?php echo $__env->yieldContent('editNebulization'); ?>"><?php echo $__env->yieldContent('editNebulization'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Tracheostomy 
<select name="Tracheostomy" id="Tracheostomy" class="form-control" value="<?php echo $__env->yieldContent('editTracheostomy'); ?>">
<option value="<?php echo $__env->yieldContent('editTracheostomy'); ?>"><?php echo $__env->yieldContent('editTracheostomy'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>CPAP/BIPAP 
            <select name="CPAP_BIPAP" id="CPAP_BIPAP" class="form-control" value="<?php echo $__env->yieldContent('editCPAP_BIPAP'); ?>">
            <option value="<?php echo $__env->yieldContent('editCPAP_BIPAP'); ?>"><?php echo $__env->yieldContent('editCPAP_BIPAP'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>ICD
            <select name="ICD" id="ICD" class="form-control" value="<?php echo $__env->yieldContent('editICD'); ?>">
            <option value="<?php echo $__env->yieldContent('editICD'); ?>"><?php echo $__env->yieldContent('editICD'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <br>
        <label>Position <input type="text" class="form-control" rows="5" name="Position" id="Position" value="<?php echo $__env->yieldContent('editPosition'); ?>"></label>
        &emsp;
        
   </div> 
   </div>   
</div>


<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse13">Vision Hearing Details</a>
        </h4>
      </div>
      <div id="collapse13" class="panel-collapse collapse">
        <div class="panel-body">
        <label>Impared
        <select name="Impared" id="Impared" class="form-control" value="<?php echo $__env->yieldContent('editImpared'); ?>">
        <option value="<?php echo $__env->yieldContent('editImpared'); ?>"><?php echo $__env->yieldContent('editImpared'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Short-Sight 
        <select name="ShortSight" id="ShortSight" class="form-control" value="<?php echo $__env->yieldContent('editShortSight'); ?>">
        <option value="<?php echo $__env->yieldContent('editShortSight'); ?>"><?php echo $__env->yieldContent('editShortSight'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Long-Sight
        <select name="LongSight" id="LongSight" class="form-control" value="<?php echo $__env->yieldContent('editLongSight'); ?>">
        <option value="<?php echo $__env->yieldContent('editLongSight'); ?>"><?php echo $__env->yieldContent('editLongSight'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <label>Wears Glasses 
        <select name="WearsGlasses" id="WearsGlasses" class="form-control" value="<?php echo $__env->yieldContent('editWearsGlasses'); ?>">
        <option value="<?php echo $__env->yieldContent('editWearsGlasses'); ?>"><?php echo $__env->yieldContent('editWearsGlasses'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        <br>
        <label>Hearing Aids 
        <select name="HearingAids" id="HearingAids" class="form-control" value="<?php echo $__env->yieldContent('editHearingAids'); ?>">
        <option value="<?php echo $__env->yieldContent('editHearingAids'); ?>"><?php echo $__env->yieldContent('editHearingAids'); ?></option>
            <option value="No">NO</option>
            <option value="YES">YES</option>
          </select>
        </label>
        &emsp;
        
   </div> 
   </div>   
</div>

</div>
</div>
</div>
<br>
<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed12">Product Details</a>
        </h4>
      </div>
      <div id="collapsed12" class="panel-collapse collapse">
        <div class="panel-body">

              <label>SKU ID<input type="text" class="form-control" rows="5" name="SKUid" id="SKUid" value="<?php echo $__env->yieldContent('editSKUid'); ?>"></label>&emsp;

               <label>Product Name<input type="text" class="form-control" rows="5" name="ProductName" id="ProductName" value="<?php echo $__env->yieldContent('editProductName'); ?>"></label>&emsp;

                <label>Demo Required<input type="text" class="form-control" rows="5" name="DemoRequired" id="DemoRequired" value="<?php echo $__env->yieldContent('editDemoRequired'); ?>"></label>&emsp;

                 <label>Availability Status<input type="text" class="form-control" rows="5" name="AvailabilityStatus" id="AvailabilityStatus" value="<?php echo $__env->yieldContent('editAvailabilityStatus'); ?>"></label>
                 &emsp;
                  <label>Availability Address<input type="text" class="form-control" rows="5" name="AvailabilityAddress" id="AvailabilityAddress" value="<?php echo $__env->yieldContent('editAvailabilityAddress'); ?>"></label>
                  &emsp;
                   <label>Selling Price<input type="text" class="form-control" rows="5" name="SellingPrice" id="SellingPrice" value="<?php echo $__env->yieldContent('editSellingPrice'); ?>"></label>
                   &emsp;
                    <label>Rental Price<input type="text" class="form-control" rows="5" name="RentalPrice" id="RentalPrice" value="<?php echo $__env->yieldContent('editRentalPrice'); ?>"></label>
                    &emsp;
                     
        
        <br>
</div></div></div>
<?php $leadid=$_GET['id'];
if(session()->has('name'))
{
  $name=session()->get('name');
}else
{
if(isset($_GET['name'])){
   $name=$_GET['name'];
}else{
   $name=NULL;
}
}
?>
<input type="hidden" name="leadid" value="<?php echo $leadid;?>">
<input type="hidden" name="sname" value="<?php echo $name;?>">


<br>
<br>
 <button type="submit" class="btn btn-success">Submit</button>
       
    </div>
  </fieldset>
</form>
</div>
      
  <?php echo $__env->make('partial.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>