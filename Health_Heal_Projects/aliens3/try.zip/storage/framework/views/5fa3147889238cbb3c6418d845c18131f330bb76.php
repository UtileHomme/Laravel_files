<?php $__env->startSection('body'); ?>
<br>
<a href="/admin/vertical" class="btn btn-info" >Home</a>


<h1><?php echo e(substr(Route::currentRouteName(),9)); ?> Mathrutvam Form</h1>
<div class="container">
       <div class="panel-group" id="accordion">   
<form class="form-horizontal" action="/vh/<?php echo $__env->yieldContent('editid'); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo $__env->yieldSection(); ?>
  <fieldset>
<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse30">Lead Details</a>
        </h4>
      </div>
      <div id="collapse30" class="panel-collapse collapse">
        <div class="panel-body">
  <?php $__currentLoopData = $leaddata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <b>Lead ID : </b><?php echo e($lead->id); ?>&emsp;&emsp;
    <b>Created At : </b><?php echo e($lead->created_at); ?>&emsp;&emsp;
    <b>Created By : </b><?php echo e($lead->createdby); ?>&emsp;&emsp;
  <b>Client First Name : </b><?php echo e($lead->fName); ?>&emsp;&emsp;
  <b>Client Middle Name : </b><?php echo e($lead->mName); ?>&emsp;&emsp;
  <b>Client Last Name : </b><?php echo e($lead->lName); ?>&emsp;&emsp;
  <b>Client Mobile Number : </b><?php echo e($lead->MobileNumber); ?>&emsp;&emsp;
  <b>Email Id:</b><?php echo e($lead->EmailId); ?>&emsp;&emsp;
  <b>Source :</b><?php echo e($lead->Source); ?>&emsp;&emsp;
  <b>Service Type : </b><?php echo e($lead->ServiceType); ?>&emsp;&emsp;
  <b>Lead Type : </b><?php echo e($lead->LeadType); ?>&emsp;&emsp;
  <b>Service Status : </b><?php echo e($lead->ServiceStatus); ?>&emsp;&emsp;
        <b>Alternate number:</b> <?php echo e($lead->Alternatenumber); ?>&emsp;&emsp;
        <b>Assessment Required: </b><?php echo e($lead->AssesmentReq); ?>&emsp;&emsp;
        <b>Patient Name:</b> <?php echo e($lead->PtfName); ?>&emsp;&emsp;
        <b>age:</b> <?php echo e($lead->age); ?>&emsp;&emsp;
        <b>Gender:</b> <?php echo e($lead->Gender); ?>&emsp;&emsp;
        <b>Realtionsip:</b> <?php echo e($lead->Relationship); ?>&emsp;&emsp;
        <b>Status:</b> <?php echo e($lead->Occupation); ?>&emsp;&emsp;

        <b>Aadhar number:</b> <?php echo e($lead->AadharNum); ?>&emsp;&emsp;
        
        <b>Service type:</b> <?php echo e($lead->ServiceType); ?>&emsp;&emsp;
        <b>General Condition:</b> <?php echo e($lead->GeneralCondition); ?>&emsp;&emsp;
        <b>Branch:</b> <?php echo e($lead->Branch); ?>&emsp;&emsp;
        <b>Requested Date:</b> <?php echo e($lead->RequestDateTime); ?>&emsp;&emsp;

        <b>Assigned to:</b> <?php echo e($lead->AssignedTo); ?>&emsp;&emsp;
        
        <b>Quoted Price:</b> &#8377; <?php echo e($lead->QuotedPrice); ?>&emsp;&emsp;
        <b>Expected Price:</b> &#8377; <?php echo e($lead->ExpectedPrice); ?>&emsp;&emsp;
        <b>Service Status:</b> <?php echo e($lead->ServiceStatus); ?>&emsp;&emsp;
        <b>Gender Prefered:</b> <?php echo e($lead->PreferedGender); ?>&emsp;&emsp;
        <b>Prefered Languages:</b> <?php echo e($lead->PreferedLanguage); ?>&emsp;&emsp;
        <b>Remarks:</b> <?php echo e($lead->Remarks); ?>&emsp;&emsp;
        
        <!-- <button><a href="<?php echo e('/cc/'.$lead->id.'/edit'); ?>">Edit &emsp;</a></button> -->
   
<br><br>
    <label>Assign TO
            <select name="assigned" id="assigned" class="form-control" >
             <option value="<?php echo $__env->yieldContent('editassigned'); ?>"><?php echo $__env->yieldContent('editassigned'); ?></option>

            <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($emp->FirstName); ?>"><?php echo e($emp->FirstName); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
              </label>&emsp;

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
</div>

  
    <div class="form-group">
 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed11">General Details</a>
        </h4>
      </div>
      <div id="collapsed11" class="panel-collapse collapse">
        <div class="panel-body">

              <label>Assessor<input type="text" class="form-control" rows="5" name="Assessor" id="Assessor" value="<?php echo $__env->yieldContent('editAssessor'); ?>"></label>&emsp;

               <label>Assess DateTime<input type="datetime-local" class="form-control" rows="5" name="AssessDateTime" id="AssessDateTime" value="<?php echo $__env->yieldContent('editAssessDateTime'); ?>"></label>&emsp;

                <label>Assess Place<input type="text" class="form-control" rows="5" name="AssessPlace" id="AssessPlace" value="<?php echo $__env->yieldContent('editAssessPlace'); ?>"></label>&emsp;

                 <label>Service Start Date<input type="date" class="form-control" rows="5" name="ServiceStartDate" id="ServiceStartDate" value="<?php echo $__env->yieldContent('editServiceStartDate'); ?>"></label>
                 &emsp;
                  <label>Service Pause<input type="text" class="form-control" rows="5" name="ServicePause" id="ServicePause" value="<?php echo $__env->yieldContent('editServicePause'); ?>"></label>
                  &emsp;
                   <label>Service End Date<input type="date" class="form-control" rows="5" name="ServiceEndDate" id="ServiceEndDate" value="<?php echo $__env->yieldContent('editServiceEndDate'); ?>"></label>
                   &emsp;
                    <label>Shift Preference<input type="text" class="form-control" rows="5" name="ShiftPreference" id="ShiftPreference" value="<?php echo $__env->yieldContent('editShiftPreference'); ?>"></label>
                    &emsp;
                     <label>Specific Requirements<input type="text" class="form-control" rows="5" name="SpecificRequirements" id="SpecificRequirements" value="<?php echo $__env->yieldContent('editSpecificRequirements'); ?>"></label>
                     &emsp;
                   <label>Days Worked<input type="text" class="form-control" rows="5" name="DaysWorked" id="DaysWorked" value="<?php echo $__env->yieldContent('editDaysWorked'); ?>"></label>
                    
        &emsp;

          <label>Latitude<input type="text" class="form-control" rows="5" name="Latitude" id="Latitude" value="<?php echo $__env->yieldContent('editLatitude'); ?>"></label>&emsp;


                   <label>Longitude<input type="text" class="form-control" rows="5" name="Longitude" id="Longitude" value="<?php echo $__env->yieldContent('editLongitude'); ?>"></label>&emsp;

        
        <br>
</div>
</div>
</div>
<br>




<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Mother's Details</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
        <label>First Name<input type="text" class="form-control" rows="5" name="FName" id="FName" value="<?php echo $__env->yieldContent('editFName'); ?>"></label>
        &emsp;
        <label>Middle Name<input type="text" class="form-control" rows="5" name="MName" id="MName" value="<?php echo $__env->yieldContent('editMName'); ?>"></label>
        &emsp;
        <label>Last Name<input type="text" class="form-control" rows="5" name="LName" id="LName" value="<?php echo $__env->yieldContent('editLName'); ?>"></label>
        &emsp;
        <label>Medications <input type="text" class="form-control" rows="5" name="Medications" id="Medications" value="<?php echo $__env->yieldContent('editMedications'); ?>"></label>
        &emsp;
        <label>Medical Diagnosis<input type="text" class="form-control" rows="5" name="MedicalDiagnosis" id="MedicalDiagnosis" value="<?php echo $__env->yieldContent('editMedicalDiagnosis'); ?>"></label>
        &emsp;
        <label>Delivery Place<input type="text" class="form-control" rows="5" name="DeliveryPlace" id="DeliveryPlace" value="<?php echo $__env->yieldContent('editDeliveryPlace'); ?>"></label>
        &emsp;
        <label>Due Date<input type="text" class="form-control" rows="5" name="DueDate" id="DueDate" value="<?php echo $__env->yieldContent('editDueDate'); ?>"></label>
        &emsp;
        <label>Delivery Type<input type="text" class="form-control" rows="5" name="DeliveryType" id="DeliveryType" value="<?php echo $__env->yieldContent('editDeliveryType'); ?>"></label>
        &emsp;
        <label>No. of Babies
        <select name="NoOfBabies" id="NoOfBabies" class="form-control" value="<?php echo $__env->yieldContent('editNoOfBabies'); ?>">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
          </select></label> &emsp;&emsp;
          <label>No. of attender required
        <select name="NoOfAttenderRequired" id="NoOfAttenderRequired" class="form-control" value="<?php echo $__env->yieldContent('editNoOfAttenderRequired'); ?>">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
          </select></label>
        <br>
        
        <br>
      </div>  
      </div>
</div>

   <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Baby Details</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">
       <label>Child DOB<input type="text" class="form-control" rows="5" name="ChildDOB" id="ChildDOB" value="<?php echo $__env->yieldContent('editChildDOB'); ?>"></label>
        &emsp;
        <label>Child Medical Diagnosis<input type="text" class="form-control" rows="5" name="ChildMedicalDiagnosis" id="ChildMedicalDiagnosis" value="<?php echo $__env->yieldContent('editChildMedicalDiagnosis'); ?>"></label>
        &emsp;
        <label>Child Medications <input type="text" class="form-control" rows="5" name="ChildMedications" id="ChildMedications" value="<?php echo $__env->yieldContent('editChildMedications'); ?>"></label>
        &emsp;
        <label>Immunization Updated <input type="text" class="form-control" rows="5" name="ImmunizationUpdated" id="ImmunizationUpdated" value="<?php echo $__env->yieldContent('editImmunizationUpdated'); ?>"></label>
        <br>
        <label>Birth Weight <input type="text" class="form-control" rows="5" name="BirthWeight" id="BirthWeight" value="<?php echo $__env->yieldContent('editBirthWeight'); ?>"></label>
        &emsp;
        <label>Discharge Weight <input type="text" class="form-control" rows="5" name="DischargeWeight" id="DischargeWeight" value="<?php echo $__env->yieldContent('editDischargeWeight'); ?>"></label>
        &emsp;
        <label>Feeding Formula <input type="text" class="form-control" rows="5" name="FeedingFormula" id="FeedingFormula" value="<?php echo $__env->yieldContent('editFeedingFormula'); ?>"></label>
        &emsp;
        <label>Feeding Issue 
		<select name="FeedingIssue" id="FeedingIssue" class="form-control" value="<?php echo $__env->yieldContent('editFeedingIssue'); ?>">
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Feeding Type <input type="text" class="form-control" rows="5" name="FeedingType" id="FeedingType" value="<?php echo $__env->yieldContent('editFeedingType'); ?>"></label>
        &emsp;
        <label>Feeding Established 
			<select name="FeedingEstablished" id="FeedingEstablished" class="form-control" value="<?php echo $__env->yieldContent('editFeedingEstablished'); ?>">
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Feeding Mode <input type="text" class="form-control" rows="5" name="FeedingMode" id="FeedingMode" value="<?php echo $__env->yieldContent('editFeedingMode'); ?>"></label>
        &emsp;
        <label>MedicalConditions <input type="text" class="form-control" rows="5" name="MedicalConditions" id="MedicalConditions" value="<?php echo $__env->yieldContent('editMedicalConditions'); ?>"></label>
        &emsp;
        <label>Length <input type="text" class="form-control" rows="5" name="Length" id="Length" value="<?php echo $__env->yieldContent('editLength'); ?>"></label>
        &emsp;
        <label>Head Circumference <input type="text" class="form-control" rows="5" name="HeadCircumference" id="HeadCircumference" value="<?php echo $__env->yieldContent('editHeadCircumference'); ?>"></label>
        &emsp;
        <label>SleepingPattern <input type="text" class="form-control" rows="5" name="SleepingPattern" id="SleepingPattern" value="<?php echo $__env->yieldContent('editSleepingPattern'); ?>"></label>
        &emsp;

        
        <br>
        </div>
        </div>
        </div>



      
<?php $leadid=$_GET['id']?>
<input type="hidden" name="leadid" value="<?php echo $leadid;?>">


<br>
<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed12">Product Details</a>
        </h4>
      </div>
      <div id="collapsed12" class="panel-collapse collapse">
        <div class="panel-body">

              <label>SKU ID<input type="text" class="form-control" rows="5" name="SKUid" id="SKUid" value="<?php echo $__env->yieldContent('editSKUid'); ?>"></label>&emsp;

               <label>Product Name<input type="text" class="form-control" rows="5" name="ProductName" id="ProductName" value="<?php echo $__env->yieldContent('editProductName'); ?>"></label>&emsp;

                <label>Demo Required<input type="text" class="form-control" rows="5" name="DemoRequired" id="DemoRequired" value="<?php echo $__env->yieldContent('editDemoRequired'); ?>"></label>&emsp;

                 <label>Availability Status<input type="text" class="form-control" rows="5" name="AvailabilityStatus" id="AvailabilityStatus" value="<?php echo $__env->yieldContent('editAvailabilityStatus'); ?>"></label>
                 &emsp;
                  <label>Availability Address<input type="text" class="form-control" rows="5" name="AvailabilityAddress" id="AvailabilityAddress" value="<?php echo $__env->yieldContent('editAvailabilityAddress'); ?>"></label>
                  &emsp;
                   <label>Selling Price<input type="text" class="form-control" rows="5" name="SellingPrice" id="SellingPrice" value="<?php echo $__env->yieldContent('editSellingPrice'); ?>"></label>
                   &emsp;
                    <label>Rental Price<input type="text" class="form-control" rows="5" name="RentalPrice" id="RentalPrice" value="<?php echo $__env->yieldContent('editRentalPrice'); ?>"></label>
                    &emsp;
                     
        
        <br>
</div></div></div>
<br>
<?php $leadid=$_GET['id'];
if(session()->has('name'))
{
  $name=session()->get('name');
}else
{
if(isset($_GET['name'])){
   $name=$_GET['name'];
}else{
   $name=NULL;
}
}
?>
<input type="hidden" name="leadid" value="<?php echo $leadid;?>">
<input type="hidden" name="sname" value="<?php echo $name;?>">
 <button type="submit" class="btn btn-success">Submit</button>
       
    </div>
  </fieldset>
</form>
</div>
      
  <?php echo $__env->make('partial.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>