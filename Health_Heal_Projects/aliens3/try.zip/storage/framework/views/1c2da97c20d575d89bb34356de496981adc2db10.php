<?php $__env->startSection('editid', $lead->id); ?>

<?php $__env->startSection('editassigned',$verc->FirstName); ?>

<?php $__env->startSection('editAssessor',$assessment->Assessor); ?>
<?php $__env->startSection('editAssessDateTime',$assessment->AssessDateTime); ?>
<?php $__env->startSection('editAssessPlace',$assessment->AssessPlace); ?>
<?php $__env->startSection('editServiceStartDate',$assessment->ServiceStartDate); ?>
<?php $__env->startSection('editServicePause',$assessment->ServicePause); ?>
<?php $__env->startSection('editServiceEndDate',$assessment->ServiceEndDate); ?>
<?php $__env->startSection('editShiftPreference',$assessment->ShiftPreference); ?>
<?php $__env->startSection('editSpecificRequirements',$assessment->SpecificRequirements); ?>
<?php $__env->startSection('editDaysWorked',$assessment->DaysWorked); ?>

<?php $__env->startSection('editSKUid', $product->SKUid); ?>
<?php $__env->startSection('editProductName', $product->ProductName); ?>
<?php $__env->startSection('editDemoRequired', $product->DemoRequired); ?>
<?php $__env->startSection('editAvailabilityStatus', $product->AvailabilityStatus); ?>
<?php $__env->startSection('editAvailabilityAddress', $product->AvailabilityAddress); ?>
<?php $__env->startSection('editSellingPrice', $product->SellingPrice); ?>
<?php $__env->startSection('editRentalPrice', $product->RentalPrice); ?>


<?php $__env->startSection('editProblemIdentified', $physioreport->ProblemIdentified); ?>
<?php $__env->startSection('editTreatment', $physioreport->Treatment); ?>


<?php $__env->startSection('editPhysiotheraphyType', $physiotheraphy->PhysiotheraphyType); ?>
<?php $__env->startSection('editMetalImplant', $physiotheraphy->MetalImplant); ?>
<?php $__env->startSection('editHypertension', $physiotheraphy->Hypertension); ?>
<?php $__env->startSection('editMedications', $physiotheraphy->Medications); ?>
<?php $__env->startSection('editOsteoporosis', $physiotheraphy->Osteoporosis); ?>
<?php $__env->startSection('editCancer', $physiotheraphy->Cancer); ?>
<?php $__env->startSection('editPregnantOrBreastFeeding', $physiotheraphy->PregnantOrBreastFeeding); ?>
<?php $__env->startSection('editDiabetes', $physiotheraphy->Diabetes); ?>
<?php $__env->startSection('editChronicInfection', $physiotheraphy->ChronicInfection); ?>
<?php $__env->startSection('editHeartDisease', $physiotheraphy->HeartDisease); ?>
<?php $__env->startSection('editEpilepsy', $physiotheraphy->Epilepsy); ?>
<?php $__env->startSection('editSurgeryUndergone', $physiotheraphy->SurgeryUndergone); ?>
<?php $__env->startSection('editAffectedArea', $physiotheraphy->AffectedArea); ?>
<?php $__env->startSection('editAssesmentDate', $physiotheraphy->AssesmentDate); ?>
<?php $__env->startSection('editPainPattern', $physiotheraphy->PainPattern); ?>
<?php $__env->startSection('editExaminationReport', $physiotheraphy->ExaminationReport); ?>
<?php $__env->startSection('editLabOrRadiologicalReport', $physiotheraphy->LabOrRadiologicalReport); ?>
<?php $__env->startSection('editMedicalDisgnosis', $physiotheraphy->MedicalDisgnosis); ?>
<?php $__env->startSection('editPhysiotherapeuticDiagnosis', $physiotheraphy->PhysiotherapeuticDiagnosis); ?>
<?php $__env->startSection('editShortTermGoal', $physiotheraphy->ShortTermGoal); ?>
<?php $__env->startSection('editLongTermGoal', $physiotheraphy->LongTermGoal); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo e(method_field('PUT')); ?>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('verticalheads.physiotherapy', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>