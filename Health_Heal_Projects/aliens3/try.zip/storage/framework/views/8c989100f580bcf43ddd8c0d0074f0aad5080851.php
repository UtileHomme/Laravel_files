<?php $__env->startSection('body'); ?>
<br>
<a href="/admin/vertical" class="btn btn-info" >Home</a>


<h1><?php echo e(substr(Route::currentRouteName(),9)); ?> Physiotheraphy Form</h1>
<div class="container">
       <div class="panel-group" id="accordion">   
<form class="form-horizontal" action="/vh/<?php echo $__env->yieldContent('editid'); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<?php $__env->startSection('editMethod'); ?>
<?php echo $__env->yieldSection(); ?>
  <fieldset>
    <div class="form-group">
 
<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse30">Lead Details</a>
        </h4>
      </div>
      <div id="collapse30" class="panel-collapse collapse">
        <div class="panel-body">
  <?php $__currentLoopData = $leaddata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <b>Lead ID : </b><?php echo e($lead->id); ?>&emsp;&emsp;
    <b>Created At : </b><?php echo e($lead->created_at); ?>&emsp;&emsp;
    <b>Created By : </b><?php echo e($lead->createdby); ?>&emsp;&emsp;
  <b>Client First Name : </b><?php echo e($lead->fName); ?>&emsp;&emsp;
  <b>Client Middle Name : </b><?php echo e($lead->mName); ?>&emsp;&emsp;
  <b>Client Last Name : </b><?php echo e($lead->lName); ?>&emsp;&emsp;
  <b>Client Mobile Number : </b><?php echo e($lead->MobileNumber); ?>&emsp;&emsp;
  <b>Email Id:</b><?php echo e($lead->EmailId); ?>&emsp;&emsp;
  <b>Source :</b><?php echo e($lead->Source); ?>&emsp;&emsp;
  <b>Service Type : </b><?php echo e($lead->ServiceType); ?>&emsp;&emsp;
  <b>Lead Type : </b><?php echo e($lead->LeadType); ?>&emsp;&emsp;
  <b>Service Status : </b><?php echo e($lead->ServiceStatus); ?>&emsp;&emsp;
        <b>Alternate number:</b> <?php echo e($lead->Alternatenumber); ?>&emsp;&emsp;
        <b>Assessment Required: </b><?php echo e($lead->AssesmentReq); ?>&emsp;&emsp;
        <b>Patient Name:</b> <?php echo e($lead->PtfName); ?>&emsp;&emsp;
        <b>age:</b> <?php echo e($lead->age); ?>&emsp;&emsp;
        <b>Gender:</b> <?php echo e($lead->Gender); ?>&emsp;&emsp;
        <b>Realtionsip:</b> <?php echo e($lead->Relationship); ?>&emsp;&emsp;
        <b>Status:</b> <?php echo e($lead->Occupation); ?>&emsp;&emsp;

        <b>Aadhar number:</b> <?php echo e($lead->AadharNum); ?>&emsp;&emsp;
        
        <b>Service type:</b> <?php echo e($lead->ServiceType); ?>&emsp;&emsp;
        <b>General Condition:</b> <?php echo e($lead->GeneralCondition); ?>&emsp;&emsp;
        <b>Branch:</b> <?php echo e($lead->Branch); ?>&emsp;&emsp;
        <b>Requested Date:</b> <?php echo e($lead->RequestDateTime); ?>&emsp;&emsp;

        <b>Assigned to:</b> <?php echo e($lead->AssignedTo); ?>&emsp;&emsp;
        
        <b>Quoted Price:</b> &#8377; <?php echo e($lead->QuotedPrice); ?>&emsp;&emsp;
        <b>Expected Price:</b> &#8377; <?php echo e($lead->ExpectedPrice); ?>&emsp;&emsp;
        <b>Service Status:</b> <?php echo e($lead->ServiceStatus); ?>&emsp;&emsp;
        <b>Gender Prefered:</b> <?php echo e($lead->PreferedGender); ?>&emsp;&emsp;
        <b>Prefered Languages:</b> <?php echo e($lead->PreferedLanguage); ?>&emsp;&emsp;
        <b>Remarks:</b> <?php echo e($lead->Remarks); ?>&emsp;&emsp;
        
        <!-- <button><a href="<?php echo e('/cc/'.$lead->id.'/edit'); ?>">Edit &emsp;</a></button> -->
   
<br><br>
    <label>Assign TO
            <select name="assigned" id="assigned" class="form-control" >
             <option value="<?php echo $__env->yieldContent('editassigned'); ?>"><?php echo $__env->yieldContent('editassigned'); ?></option>

            <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($emp->FirstName); ?>"><?php echo e($emp->FirstName); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
              </label>&emsp;

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
</div>
</div>



 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed11">General Details</a>
        </h4>
      </div>
      <div id="collapsed11" class="panel-collapse collapse">
        <div class="panel-body">

              <label>Assessor<input type="text" class="form-control" rows="5" name="Assessor" id="Assessor" value="<?php echo $__env->yieldContent('editAssessor'); ?>"></label>&emsp;

               <label>Assess DateTime<input type="datetime-local" class="form-control" rows="5" name="AssessDateTime" id="AssessDateTime" value="<?php echo $__env->yieldContent('editAssessDateTime'); ?>"></label>&emsp;

                <label>Assess Place<input type="text" class="form-control" rows="5" name="AssessPlace" id="AssessPlace" value="<?php echo $__env->yieldContent('editAssessPlace'); ?>"></label>&emsp;

                 <label>Service Start Date<input type="date" class="form-control" rows="5" name="ServiceStartDate" id="ServiceStartDate" value="<?php echo $__env->yieldContent('editServiceStartDate'); ?>"></label>
                 &emsp;
                  <label>Service Pause<input type="text" class="form-control" rows="5" name="ServicePause" id="ServicePause" value="<?php echo $__env->yieldContent('editServicePause'); ?>"></label>
                  &emsp;
                   <label>Service End Date<input type="date" class="form-control" rows="5" name="ServiceEndDate" id="ServiceEndDate" value="<?php echo $__env->yieldContent('editServiceEndDate'); ?>"></label>
                   &emsp;
                    <label>Shift Preference<input type="text" class="form-control" rows="5" name="ShiftPreference" id="ShiftPreference" value="<?php echo $__env->yieldContent('editShiftPreference'); ?>"></label>
                    &emsp;
                     <label>Specific Requirements<input type="text" class="form-control" rows="5" name="SpecificRequirements" id="SpecificRequirements" value="<?php echo $__env->yieldContent('editSpecificRequirements'); ?>"></label>&emsp;

                     &emsp;
                   <label>Days Worked<input type="text" class="form-control" rows="5" name="DaysWorked" id="DaysWorked" value="<?php echo $__env->yieldContent('editDaysWorked'); ?>"></label>
                    
                      <label>Latitude<input type="text" class="form-control" rows="5" name="Latitude" id="Latitude" value="<?php echo $__env->yieldContent('editLatitude'); ?>"></label>&emsp;


                   <label>Longitude<input type="text" class="form-control" rows="5" name="Longitude" id="Longitude" value="<?php echo $__env->yieldContent('editLongitude'); ?>"></label>
        &emsp;&emsp;

        
        <br>
</div>
</div>
</div>
<br>


      

   <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Physiotherapy Details</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">
       <label>Physiotheraphy Type
          <select name="PhysiotheraphyType" id="PhysiotheraphyType" class="form-control" value="<?php echo $__env->yieldContent('editPhysiotheraphyType'); ?>">
          <option value=""></option>
          <option value="Post-Surgical Rehabilatation">Post-Surgical Rehabilatation</option>
            <option value="Pediatric Physio">Pediatric Physio</option>
            <option value="Neurological Disorder">Neurological Disorder</option>
            <option value="Stroke Rehabilitation">Stroke Rehabilitation</option>
            <option value="Treat and Manage CRIs and SRIs">Treat and Manage CRIs and SRIs</option>
            <option value="Others">Others</option>
           
          </select>

       </label>
        &emsp;
        <label>Metal Implant
          <select name="MetalImplant" id="MetalImplant" class="form-control" value="<?php echo $__env->yieldContent('editMetalImplant'); ?>">
          <option value=""></option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Hypertension
          <select name="Hypertension" id="Hypertension" class="form-control" value="<?php echo $__env->yieldContent('editHypertension'); ?>">
          <option value=""></option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Medications
          <select name="Medications" id="Medications" class="form-control" value="<?php echo $__env->yieldContent('editMedications'); ?>">
          <option value=""></option>
            < <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>          
        </label>
        &emsp;
        <label>Osteoporosis
          <select name="Osteoporosis" id="Osteoporosis" class="form-control" value="<?php echo $__env->yieldContent('editOsteoporosis'); ?>">
          <option value=""></option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Cancer
        <select name="Cancer" id="Cancer" class="form-control" value="<?php echo $__env->yieldContent('editCancer'); ?>">
        <option value=""></option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Pregnant OrBreast Feeding
          <select name="PregnantOrBreastFeeding" id="PregnantOrBreastFeeding" class="form-control" value="<?php echo $__env->yieldContent('editPregnantOrBreastFeeding'); ?>">
          <option value=""></option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Diabetes
        <select name="Diabetes" id="Diabetes" class="form-control" value="<?php echo $__env->yieldContent('editDiabetes'); ?>">
        <option value=""></option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Chronic Infection
        <select name="ChronicInfection" id="ChronicInfection" class="form-control" value="<?php echo $__env->yieldContent('editChronicInfection'); ?>">
        <option value=""></option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Heart Disease
          <select name="HeartDisease" id="HeartDisease" class="form-control" value="<?php echo $__env->yieldContent('editHeartDisease'); ?>">
          <option value=""></option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
          </label>
        &emsp;
        <label>Epilepsy
        <select name="Epilepsy" id="Epilepsy" class="form-control" value="<?php echo $__env->yieldContent('editEpilepsy'); ?>">
        <option value=""></option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Past/Present Surgery Details

          <select name="SurgeryUndergone" id="SurgeryUndergone" class="form-control" value="<?php echo $__env->yieldContent('editSurgeryUndergone'); ?>">
          <option value=""></option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Affected Area
           <select name="AffectedArea" id="AffectedArea" class="form-control" value="<?php echo $__env->yieldContent('editAffectedArea'); ?>">
           <option value=""></option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        
        <label>Pain Pattern
          <select name="PainPattern" id="PainPattern" class="form-control" value="<?php echo $__env->yieldContent('editPainPattern'); ?>">
          <option value=""></option>
            <option value="Arravating">Arravating</option>
            <option value="Alleviating Factor">Alleviating Factor</option>
            <option value="Night Pain">Night Pain</option>
            <option value="Nature of Pain">Nature of Pain</option>
          </select>
        </label>
        &emsp;
        <label>Examination Report
      <select name="ExaminationReport" id="ExaminationReport" class="form-control" value="<?php echo $__env->yieldContent('editExaminationReport'); ?>">
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Lab Or Radiological Report
        <select name="LabOrRadiologicalReport" id="LabOrRadiologicalReport" class="form-control" value="<?php echo $__env->yieldContent('editLabOrRadiologicalReport'); ?>">
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Medical Disgnosis
      <select name="MedicalDisgnosis" id="MedicalDisgnosis" class="form-control" value="<?php echo $__env->yieldContent('editMedicalDisgnosis'); ?>">
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Physiotherapeutic Diagnosis
          <select name="PhysiotherapeuticDiagnosis" id="PhysiotherapeuticDiagnosis" class="form-control" value="<?php echo $__env->yieldContent('editPhysiotherapeuticDiagnosis'); ?>">
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Assesment Date<input type="date" class="form-control" rows="5" name="AssesmentDate" id="AssesmentDate" value="<?php echo $__env->yieldContent('editAssesmentDate'); ?>"></label>
        &emsp;
        <label>Short Term Goal<input type="text" class="form-control" rows="5" name="ShortTermGoal" id="ShortTermGoal" value="<?php echo $__env->yieldContent('editShortTermGoal'); ?>"></label>
        &emsp;
         <label>Long Term Goal<input type="text" class="form-control" rows="5" name="LongTermGoal" id="LongTermGoal" value="<?php echo $__env->yieldContent('editLongTermGoal'); ?>"></label>
        &emsp;
        
        <br>
        
        <br>
        </div>
        </div>
        </div>

<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Physiotherapy Report Details</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
       <label>Problem Identified<input type="text" class="form-control" rows="5" name="ProblemIdentified" id="ProblemIdentified" value="<?php echo $__env->yieldContent('editProblemIdentified'); ?>"></label>
        &emsp;
        <label>Treatment<input type="text" class="form-control" rows="5" name="Treatment" id="Treatment" value="<?php echo $__env->yieldContent('editTreatment'); ?>"></label>
        &emsp;
        </div>
        </div>
        </div>


<?php $leadid=$_GET['id']?>
<input type="hidden" name="leadid" value="<?php echo $leadid;?>">


<br>

<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed12">Product Details</a>
        </h4>
      </div>
      <div id="collapsed12" class="panel-collapse collapse">
        <div class="panel-body">

              <label>SKU ID<input type="text" class="form-control" rows="5" name="SKUid" id="SKUid" value="<?php echo $__env->yieldContent('editSKUid'); ?>"></label>&emsp;

               <label>Product Name<input type="text" class="form-control" rows="5" name="ProductName" id="ProductName" value="<?php echo $__env->yieldContent('editProductName'); ?>"></label>&emsp;

                <label>Demo Required<input type="text" class="form-control" rows="5" name="DemoRequired" id="DemoRequired" value="<?php echo $__env->yieldContent('editDemoRequired'); ?>"></label>&emsp;

                 <label>Availability Status<input type="text" class="form-control" rows="5" name="AvailabilityStatus" id="AvailabilityStatus" value="<?php echo $__env->yieldContent('editAvailabilityStatus'); ?>"></label>
                 &emsp;
                  <label>Availability Address<input type="text" class="form-control" rows="5" name="AvailabilityAddress" id="AvailabilityAddress" value="<?php echo $__env->yieldContent('editAvailabilityAddress'); ?>"></label>
                  &emsp;
                   <label>Selling Price<input type="text" class="form-control" rows="5" name="SellingPrice" id="SellingPrice" value="<?php echo $__env->yieldContent('editSellingPrice'); ?>"></label>
                   &emsp;
                    <label>Rental Price<input type="text" class="form-control" rows="5" name="RentalPrice" id="RentalPrice" value="<?php echo $__env->yieldContent('editRentalPrice'); ?>"></label>
                    &emsp;
                     
        
        <br>
</div></div></div>
<br>

<?php $leadid=$_GET['id'];
if(session()->has('name'))
{
  $name=session()->get('name');
}else
{
if(isset($_GET['name'])){
   $name=$_GET['name'];
}else{
   $name=NULL;
}
}
?>
<input type="hidden" name="leadid" value="<?php echo $leadid;?>">
<input type="hidden" name="sname" value="<?php echo $name;?>">

 <button type="submit" class="btn btn-success">Submit</button>
       
    </div>
  </fieldset>
</form>
</div>
      
  <?php echo $__env->make('partial.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>