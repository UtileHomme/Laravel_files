<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class mother extends Model
{
    //
}
