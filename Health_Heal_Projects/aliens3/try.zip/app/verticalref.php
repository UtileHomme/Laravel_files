<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class verticalref extends Model
{
    //
}
