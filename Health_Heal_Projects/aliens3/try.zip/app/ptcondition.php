<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ptcondition extends Model
{
    //
}
