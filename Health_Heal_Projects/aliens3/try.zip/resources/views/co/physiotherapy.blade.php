@extends('layout.app')
@section('body')
<br>
<a href="/admin/coordinator" class="btn btn-info" >Home</a>


<h1>{{substr(Route::currentRouteName(),9)}} Physiotheraphy Form</h1>
<div class="container">
       <div class="panel-group" id="accordion">   
<form class="form-horizontal" action="/vh/@yield('editid')" method="POST">
{{csrf_field()}}
@section('editMethod')
@show
  <fieldset>
    <div class="form-group">
 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse30">Lead Details</a>
        </h4>
      </div>
      <div id="collapse30" class="panel-collapse collapse">
        <div class="panel-body">
  @foreach ($leaddata as $lead)

    <b>Lead ID : </b>{{$lead->id}}&emsp;&emsp;
    <b>Created At : </b>{{$lead->created_at}}&emsp;&emsp;
    <b>Created By : </b>{{$lead->createdby}}&emsp;&emsp;
  <b>Client First Name : </b>{{$lead->fName}}&emsp;&emsp;
  <b>Client Middle Name : </b>{{$lead->mName}}&emsp;&emsp;
  <b>Client Last Name : </b>{{$lead->lName}}&emsp;&emsp;
  <b>Client Mobile Number : </b>{{$lead->MobileNumber}}&emsp;&emsp;
  <b>Email Id:</b>{{$lead->EmailId}}&emsp;&emsp;
  <b>Source :</b>{{$lead->Source}}&emsp;&emsp;
  <b>Service Type : </b>{{$lead->ServiceType}}&emsp;&emsp;
  <b>Lead Type : </b>{{$lead->LeadType}}&emsp;&emsp;
  <b>Service Status : </b>{{$lead->ServiceStatus}}&emsp;&emsp;
        <b>Alternate number:</b> {{$lead->Alternatenumber}}&emsp;&emsp;
        <b>Assessment Required: </b>{{$lead->AssesmentReq}}&emsp;&emsp;
        <b>Patient Name:</b> {{$lead->PtfName}}&emsp;&emsp;
        <b>age:</b> {{$lead->age}}&emsp;&emsp;
        <b>Gender:</b> {{$lead->Gender}}&emsp;&emsp;
        <b>Realtionsip:</b> {{$lead->Relationship}}&emsp;&emsp;
        <b>Status:</b> {{$lead->Occupation}}&emsp;&emsp;

        <b>Aadhar number:</b> {{$lead->AadharNum}}&emsp;&emsp;
        
        <b>Service type:</b> {{$lead->ServiceType}}&emsp;&emsp;
        <b>General Condition:</b> {{$lead->GeneralCondition}}&emsp;&emsp;
        <b>Branch:</b> {{$lead->Branch}}&emsp;&emsp;
        <b>Requested Date:</b> {{$lead->RequestDateTime}}&emsp;&emsp;

        <b>Assigned to:</b> {{$lead->AssignedTo}}&emsp;&emsp;
        
        <b>Quoted Price:</b> &#8377; {{$lead->QuotedPrice}}&emsp;&emsp;
        <b>Expected Price:</b> &#8377; {{$lead->ExpectedPrice}}&emsp;&emsp;
        <b>Service Status:</b> {{$lead->ServiceStatus}}&emsp;&emsp;
        <b>Gender Prefered:</b> {{$lead->PreferedGender}}&emsp;&emsp;
        <b>Prefered Languages:</b> {{$lead->PreferedLanguage}}&emsp;&emsp;
        <b>Remarks:</b> {{$lead->Remarks}}&emsp;&emsp;
        
        <!-- <button><a href="{{'/cc/'.$lead->id.'/edit'}}">Edit &emsp;</a></button> -->
   
<br><br>
    <!-- <label>Assign TO
            <select name="assigned" id="assigned" class="form-control" >
             <option value="@yield('editassigned')">@yield('editassigned')</option>

            @foreach($emp as $emp)
            <option value="{{ $emp->FirstName }}">{{ $emp->FirstName }}</option>
            @endforeach
           </select>
              </label>&emsp; -->

@endforeach
</div>
</div>
</div>



 <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed11">General Details</a>
        </h4>
      </div>
      <div id="collapsed11" class="panel-collapse collapse">
        <div class="panel-body">

              <label>Assessor<input type="text" class="form-control" rows="5" name="Assessor" id="Assessor" value="@yield('editAssessor')"></label>&emsp;

               <label>Assess DateTime<input type="datetime-local" class="form-control" rows="5" name="AssessDateTime" id="AssessDateTime" value="@yield('editAssessDateTime')"></label>&emsp;

                <label>Assess Place<input type="text" class="form-control" rows="5" name="AssessPlace" id="AssessPlace" value="@yield('editAssessPlace')"></label>&emsp;

                 <label>Service Start Date<input type="date" class="form-control" rows="5" name="ServiceStartDate" id="ServiceStartDate" value="@yield('editServiceStartDate')"></label>
                 &emsp;
                  <label>Service Pause<input type="text" class="form-control" rows="5" name="ServicePause" id="ServicePause" value="@yield('editServicePause')"></label>
                  &emsp;
                   <label>Service End Date<input type="date" class="form-control" rows="5" name="ServiceEndDate" id="ServiceEndDate" value="@yield('editServiceEndDate')"></label>
                   &emsp;
                    <label>Shift Preference<input type="text" class="form-control" rows="5" name="ShiftPreference" id="ShiftPreference" value="@yield('editShiftPreference')"></label>
                    &emsp;
                     <label>Specific Requirements<input type="text" class="form-control" rows="5" name="SpecificRequirements" id="SpecificRequirements" value="@yield('editSpecificRequirements')"></label>&emsp;

                     &emsp;
                   <label>Days Worked<input type="text" class="form-control" rows="5" name="DaysWorked" id="DaysWorked" value="@yield('editDaysWorked')"></label>
                    
                      <label>Latitude<input type="text" class="form-control" rows="5" name="Latitude" id="Latitude" value="@yield('editLatitude')"></label>&emsp;


                   <label>Longitude<input type="text" class="form-control" rows="5" name="Longitude" id="Longitude" value="@yield('editLongitude')"></label>
        &emsp;&emsp;

        
        <br>
</div>
</div>
</div>
<br>


      

   <div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Physiotherapy Details</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse">
        <div class="panel-body">
       <label>Physiotheraphy Type
          <select name="PhysiotheraphyType" id="PhysiotheraphyType" class="form-control" value="@yield('editPhysiotheraphyType')">
          <option value="@yield('editPhysiotheraphyType')">@yield('editPhysiotheraphyType')</option>
          <option value="Post-Surgical Rehabilatation">Post-Surgical Rehabilatation</option>
            <option value="Pediatric Physio">Pediatric Physio</option>
            <option value="Neurological Disorder">Neurological Disorder</option>
            <option value="Stroke Rehabilitation">Stroke Rehabilitation</option>
            <option value="Treat and Manage CRIs and SRIs">Treat and Manage CRIs and SRIs</option>
            <option value="Others">Others</option>
           
          </select>

       </label>
        &emsp;
        <label>Metal Implant
          <select name="MetalImplant" id="MetalImplant" class="form-control" value="@yield('editMetalImplant')">
          <option value="@yield('editMetalImplant')">@yield('editMetalImplant')</option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Hypertension
          <select name="Hypertension" id="Hypertension" class="form-control" value="@yield('editHypertension')">
          <option value="@yield('editHypertension')">@yield('editHypertension')</option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Medications
          <select name="Medications" id="Medications" class="form-control" value="@yield('editMedications')">
          <option value="@yield('editMedications')">@yield('editMedications')</option>
            < <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>          
        </label>
        &emsp;
        <label>Osteoporosis
          <select name="Osteoporosis" id="Osteoporosis" class="form-control" value="@yield('editOsteoporosis')">
          <option value="@yield('editOsteoporosis')">@yield('editOsteoporosis')</option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Cancer
        <select name="Cancer" id="Cancer" class="form-control" value="@yield('editCancer')">
        <option value="@yield('editCancer')">@yield('editCancer')</option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Pregnant OrBreast Feeding
          <select name="PregnantOrBreastFeeding" id="PregnantOrBreastFeeding" class="form-control" value="@yield('editPregnantOrBreastFeeding')">
          <option value="@yield('editPregnantOrBreastFeeding')">@yield('editPregnantOrBreastFeeding')</option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Diabetes
        <select name="Diabetes" id="Diabetes" class="form-control" value="@yield('editDiabetes')">
        <option value="@yield('editDiabetes')">@yield('editDiabetes')</option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Chronic Infection
        <select name="ChronicInfection" id="ChronicInfection" class="form-control" value="@yield('editChronicInfection')">
        <option value="@yield('editChronicInfection')">@yield('editChronicInfection')</option>
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Heart Disease
          <select name="HeartDisease" id="HeartDisease" class="form-control" value="@yield('editHeartDisease')">
          <option value="@yield('editHeartDisease')">@yield('editHeartDisease')</option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
          </label>
        &emsp;
        <label>Epilepsy
        <select name="Epilepsy" id="Epilepsy" class="form-control" value="@yield('editEpilepsy')">
        <option value="@yield('editEpilepsy')">@yield('editEpilepsy')</option>
             <option value="Present">Present</option>
            <option value="Absent">Absent</option>
             <option value="Patient is not Aware">Patient is not Aware</option>
          </select>
        </label>
        &emsp;
        <label>Past/Present Surgery Details

          <select name="SurgeryUndergone" id="SurgeryUndergone" class="form-control" value="@yield('editSurgeryUndergone')">
          <option value="@yield('editSurgeryUndergone')">@yield('editSurgeryUndergone')</option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Affected Area
           <select name="AffectedArea" id="AffectedArea" class="form-control" value="@yield('editAffectedArea')">
           <option value="@yield('editAffectedArea')">@yield('editAffectedArea')</option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        
        <label>Pain Pattern
          <select name="PainPattern" id="PainPattern" class="form-control" value="@yield('editPainPattern')">
          <option value="@yield('editPainPattern')">@yield('editPainPattern')</option>
            <option value="Arravating">Arravating</option>
            <option value="Alleviating Factor">Alleviating Factor</option>
            <option value="Night Pain">Night Pain</option>
            <option value="Nature of Pain">Nature of Pain</option>
          </select>
        </label>
        &emsp;
        <label>Examination Report
      <select name="ExaminationReport" id="ExaminationReport" class="form-control" value="@yield('editExaminationReport')">
            <option value="@yield('editExaminationReport')">@yield('editExaminationReport')</option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Lab Or Radiological Report
        <select name="LabOrRadiologicalReport" id="LabOrRadiologicalReport" class="form-control" value="@yield('editLabOrRadiologicalReport')">
            <option value="@yield('editLabOrRadiologicalReport')">@yield('editLabOrRadiologicalReport')</option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Medical Disgnosis
      <select name="MedicalDisgnosis" id="MedicalDisgnosis" class="form-control" value="@yield('editMedicalDisgnosis')">
            <option value="@yield('editMedicalDisgnosis')">@yield('editMedicalDisgnosis')</option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Physiotherapeutic Diagnosis
          <select name="PhysiotherapeuticDiagnosis" id="PhysiotherapeuticDiagnosis" class="form-control" value="@yield('editPhysiotherapeuticDiagnosis')">
            <option value="@yield('editPhysiotherapeuticDiagnosis')">@yield('editPhysiotherapeuticDiagnosis')</option>
            <option value="No">No</option>
            <option value="Yes">Yes</option>
          </select>
        </label>
        &emsp;
        <label>Assesment Date<input type="date" class="form-control" rows="5" name="AssesmentDate" id="AssesmentDate" value="@yield('editAssesmentDate')"></label>
        &emsp;
        <label>Short Term Goal<input type="text" class="form-control" rows="5" name="ShortTermGoal" id="ShortTermGoal" value="@yield('editShortTermGoal')"></label>
        &emsp;
         <label>Long Term Goal<input type="text" class="form-control" rows="5" name="LongTermGoal" id="LongTermGoal" value="@yield('editLongTermGoal')"></label>
        &emsp;
        
        <br>
        
        <br>
        </div>
        </div>
        </div>

<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Physiotherapy Report Details</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <div class="panel-body">
       <label>Problem Identified<input type="text" class="form-control" rows="5" name="ProblemIdentified" id="ProblemIdentified" value="@yield('editProblemIdentified')"></label>
        &emsp;
        <label>Treatment<input type="text" class="form-control" rows="5" name="Treatment" id="Treatment" value="@yield('editTreatment')"></label>
        &emsp;
        </div>
        </div>
        </div>


<?php $leadid=$_GET['id']?>
<input type="hidden" name="leadid" value="<?php echo $leadid;?>">


<br>

<div class="panel panel-default">
      <div class="panel-heading">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapsed12">Product Details</a>
        </h4>
      </div>
      <div id="collapsed12" class="panel-collapse collapse">
        <div class="panel-body">

              <label>SKU ID<input type="text" class="form-control" rows="5" name="SKUid" id="SKUid" value="@yield('editSKUid')"></label>&emsp;

               <label>Product Name<input type="text" class="form-control" rows="5" name="ProductName" id="ProductName" value="@yield('editProductName')"></label>&emsp;

                <label>Demo Required<input type="text" class="form-control" rows="5" name="DemoRequired" id="DemoRequired" value="@yield('editDemoRequired')"></label>&emsp;

                 <label>Availability Status<input type="text" class="form-control" rows="5" name="AvailabilityStatus" id="AvailabilityStatus" value="@yield('editAvailabilityStatus')"></label>
                 &emsp;
                  <label>Availability Address<input type="text" class="form-control" rows="5" name="AvailabilityAddress" id="AvailabilityAddress" value="@yield('editAvailabilityAddress')"></label>
                  &emsp;
                   <label>Selling Price<input type="text" class="form-control" rows="5" name="SellingPrice" id="SellingPrice" value="@yield('editSellingPrice')"></label>
                   &emsp;
                    <label>Rental Price<input type="text" class="form-control" rows="5" name="RentalPrice" id="RentalPrice" value="@yield('editRentalPrice')"></label>
                    &emsp;
                     
        
        <br>
</div></div></div>
<br>
<?php $leadid=$_GET['id'];
if(session()->has('name'))
{
  $name=session()->get('name');
}else
{
if(isset($_GET['name'])){
   $name=$_GET['name'];
}else{
   $name=NULL;
}
}
?>
<input type="hidden" name="leadid" value="<?php echo $leadid;?>">
<input type="hidden" name="sname" value="<?php echo $name;?>">
 <button type="submit" class="btn btn-success">Submit</button>
       
    </div>
  </fieldset>
</form>
</div>
      
  @include('partial.errors')
</div>
@endsection